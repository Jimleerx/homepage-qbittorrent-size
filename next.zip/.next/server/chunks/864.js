"use strict";
exports.id = 864;
exports.ids = [864];
exports.modules = {

/***/ 864:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Widget)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2469);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Widget({
  options
}) {
  const {
    cluster,
    nodes
  } = options;
  const {
    t,
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
  const defaultData = {
    cpu: {
      load: 0,
      total: 0,
      percent: 0
    },
    memory: {
      used: 0,
      total: 0,
      free: 0,
      precent: 0
    }
  };
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/kubernetes?${new URLSearchParams({
    lang: i18n.language
  }).toString()}`, {
    refreshInterval: 1500
  });

  if (error || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "flex flex-row items-center justify-end",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
          className: "flex flex-row items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_1__.BiError, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
            className: "flex flex-col ml-3 text-left",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-sm",
              children: t("widget.api_error")
            })
          })]
        })
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: "flex flex-row self-center flex-wrap justify-between",
        children: [cluster.show && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_node__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
          type: "cluster",
          options: options.cluster,
          data: defaultData
        }, "cluster"), nodes.show && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_node__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
          type: "node",
          options: options.nodes,
          data: defaultData
        }, "nodes")]
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: "flex flex-row self-center flex-wrap justify-between",
      children: [cluster.show && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_node__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        type: "cluster",
        options: options.cluster,
        data: data.cluster
      }, "cluster"), nodes.show && data.nodes && data.nodes.map(node => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(_node__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        type: "node",
        options: options.nodes,
        data: node
      }, node.name))]
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2469:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Node)
});

// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/fi"
var fi_ = __webpack_require__(2750);
// EXTERNAL MODULE: external "react-icons/si"
var si_ = __webpack_require__(764);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/widgets/kubernetes/usage-bar.jsx

function UsageBar({
  percent
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "mt-0.5 w-full bg-theme-800/30 rounded-full h-1 dark:bg-theme-200/20",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bg-theme-800/70 h-1 rounded-full dark:bg-theme-200/50 transition-all duration-1000",
      style: {
        width: `${percent}%`
      }
    })
  });
}
;// CONCATENATED MODULE: ./src/components/widgets/kubernetes/node.jsx







function Node({
  type,
  options,
  data
}) {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();

  function icon() {
    if (type === "cluster") {
      return /*#__PURE__*/jsx_runtime_.jsx(si_.SiKubernetes, {
        className: "text-theme-800 dark:text-theme-200 w-5 h-5"
      });
    }

    if (data.ready) {
      return /*#__PURE__*/jsx_runtime_.jsx(fi_.FiServer, {
        className: "text-theme-800 dark:text-theme-200 w-5 h-5"
      });
    }

    return /*#__PURE__*/jsx_runtime_.jsx(fi_.FiAlertTriangle, {
      className: "text-theme-800 dark:text-theme-200 w-5 h-5"
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap ml-4",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex flex-row self-center flex-wrap justify-between",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [icon(), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "pl-0.5",
              children: t("common.number", {
                value: data.cpu.percent,
                style: "unit",
                unit: "percent",
                maximumFractionDigits: 0
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(fi_.FiCpu, {
              className: "text-theme-800 dark:text-theme-200 w-3 h-3"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(UsageBar, {
            percent: data.cpu.percent
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "pl-0.5",
              children: t("common.bytes", {
                value: data.memory.free,
                maximumFractionDigits: 0,
                binary: true
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(fa_.FaMemory, {
              className: "text-theme-800 dark:text-theme-200 w-3 h-3"
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx(UsageBar, {
            percent: data.memory.percent
          }), options.showLabel && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "pt-1 text-center text-theme-800 dark:text-theme-200 text-xs",
            children: type === "cluster" ? options.label : data.name
          })]
        })]
      })
    })
  });
}

/***/ })

};
;