"use strict";
exports.id = 6007;
exports.ids = [6007];
exports.modules = {

/***/ 6007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Widget)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4181);
/* harmony import */ var utils_contexts_settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9317);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const cpuSensorLabels = ["cpu_thermal", "Core", "Tctl"];

function convertToFahrenheit(t) {
  return t * 9 / 5 + 32;
}

function Widget({
  options
}) {
  const {
    t,
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    settings
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(utils_contexts_settings__WEBPACK_IMPORTED_MODULE_7__/* .SettingsContext */ .J);
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/glances?${new URLSearchParams(_objectSpread({
    lang: i18n.language
  }, options)).toString()}`, {
    refreshInterval: 1500
  });

  if (error || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: "flex flex-row items-center justify-end",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-row items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__.BiError, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
            className: "flex flex-col ml-3 text-left",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-sm",
              children: t("widget.api_error")
            })
          })]
        })
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
      className: "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap ml-4",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex flex-row self-center flex-wrap justify-between",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex-none flex flex-row items-center mr-3 py-1.5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiCpu, {
            className: "text-theme-800 dark:text-theme-200 w-5 h-5"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: "flex flex-col ml-3 text-left min-w-[85px]",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
                className: "pl-0.5 text-xs",
                children: t("glances.wait")
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              percent: "0"
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex-none flex flex-row items-center mr-3 py-1.5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaMemory, {
            className: "text-theme-800 dark:text-theme-200 w-5 h-5"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: "flex flex-col ml-3 text-left min-w-[85px]",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
                className: "pl-0.5 text-xs",
                children: t("glances.wait")
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
              percent: "0"
            })]
          })]
        })]
      }), options.label && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
        className: "ml-6 pt-1 text-center text-theme-800 dark:text-theme-200 text-xs",
        children: options.label
      })]
    });
  }

  const unit = options.units === "imperial" ? "fahrenheit" : "celsius";
  let mainTemp = 0;
  let maxTemp = 80;
  const cpuSensors = data.sensors?.filter(s => cpuSensorLabels.some(label => s.label.startsWith(label)) && s.type === "temperature_core");

  if (options.cputemp && cpuSensors) {
    try {
      mainTemp = cpuSensors.reduce((acc, s) => acc + s.value, 0) / cpuSensors.length;
      maxTemp = Math.max(cpuSensors.reduce((acc, s) => acc + s.warning, 0) / cpuSensors.length, maxTemp);

      if (unit === "fahrenheit") {
        mainTemp = convertToFahrenheit(mainTemp);
        maxTemp = convertToFahrenheit(maxTemp);
      }
    } catch (e) {// cpu sensor retrieval failed
    }
  }

  const tempPercent = Math.round(mainTemp / maxTemp * 100);
  let disks = [];

  if (options.disk) {
    disks = Array.isArray(options.disk) ? options.disk.map(disk => data.fs.find(d => d.mnt_point === disk)).filter(d => d) : [data.fs.find(d => d.mnt_point === options.disk)].filter(d => d);
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("a", {
    href: options.url,
    target: settings.target ?? "_blank",
    className: "flex flex-col max-w:full sm:basis-auto self-center grow-0 flex-wrap",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
      className: "flex flex-row self-center flex-wrap justify-between",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiCpu, {
          className: "text-theme-800 dark:text-theme-200 w-5 h-5"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5",
              children: t("common.number", {
                value: data.cpu.total,
                style: "unit",
                unit: "percent",
                maximumFractionDigits: 0
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.cpu")
            })]
          }), options.expanded && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5 pr-1",
              children: t("common.number", {
                value: data.load.min15,
                style: "unit",
                unit: "percent",
                maximumFractionDigits: 0
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.load")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            percent: data.cpu.total
          })]
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaMemory, {
          className: "text-theme-800 dark:text-theme-200 w-5 h-5"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5",
              children: t("common.bytes", {
                value: data.mem.free,
                maximumFractionDigits: 1,
                binary: true
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.free")
            })]
          }), options.expanded && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5 pr-1",
              children: t("common.bytes", {
                value: data.mem.total,
                maximumFractionDigits: 1,
                binary: true
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.total")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            percent: data.mem.percent
          })]
        })]
      }), disks.map(disk => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiHardDrive, {
          className: "text-theme-800 dark:text-theme-200 w-5 h-5"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5",
              children: t("common.bytes", {
                value: disk.free
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.free")
            })]
          }), options.expanded && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5 pr-1",
              children: t("common.bytes", {
                value: disk.size
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.total")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            percent: disk.percent
          })]
        })]
      }, disk.mnt_point)), options.cputemp && mainTemp > 0 && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaThermometerHalf, {
          className: "text-theme-800 dark:text-theme-200 w-5 h-5"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5",
              children: t("common.number", {
                value: mainTemp,
                maximumFractionDigits: 1,
                style: "unit",
                unit
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.temp")
            })]
          }), options.expanded && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5 pr-1",
              children: t("common.number", {
                value: maxTemp,
                maximumFractionDigits: 1,
                style: "unit",
                unit
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.warn")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            percent: tempPercent
          })]
        })]
      }), options.uptime && data.uptime && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
        className: "flex-none flex flex-row items-center mr-3 py-1.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaRegClock, {
          className: "text-theme-800 dark:text-theme-200 w-5 h-5"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left min-w-[85px]",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsxs)("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs flex flex-row justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pl-0.5",
              children: data.uptime.replace(" days,", t("glances.days")).replace(/:\d\d:\d\d$/g, t("glances.hours"))
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
              className: "pr-1",
              children: t("glances.uptime")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx(_resources_usage_bar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            percent: Math.round(new Date().getSeconds() / 60 * 100)
          })]
        })]
      })]
    }), options.label && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_8__.jsx("div", {
      className: "pt-1 text-center text-theme-800 dark:text-theme-200 text-xs",
      children: options.label
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UsageBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function UsageBar({
  percent
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: "mt-0.5 w-full bg-theme-800/30 rounded-full h-1 dark:bg-theme-200/20",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "bg-theme-800/70 h-1 rounded-full dark:bg-theme-200/50 transition-all duration-1000",
      style: {
        width: `${percent}%`
      }
    })
  });
}

/***/ })

};
;