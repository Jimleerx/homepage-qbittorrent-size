"use strict";
exports.id = 7;
exports.ids = [7];
exports.modules = {

/***/ 3688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Icon)
});

// EXTERNAL MODULE: external "react-icons/wi"
var wi_ = __webpack_require__(5744);
;// CONCATENATED MODULE: ./src/utils/weather/condition-map.js
// Code primarely based on Flame's ConditionMap class
// https://github.com/pawelmalak/flame/blob/master/client/src/components/UI/Icons/WeatherIcon/IconMapping.ts

const conditions = [{
  code: 1000,
  icon: {
    day: wi_.WiDaySunny,
    night: wi_.WiNightClear
  }
}, {
  code: 1003,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightPartlyCloudy
  }
}, {
  code: 1006,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightCloudy
  }
}, {
  code: 1009,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightCloudy
  }
}, {
  code: 1030,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 1063,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1066,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1069,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightRainMix
  }
}, {
  code: 1072,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightSleet
  }
}, {
  code: 1087,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightThunderstorm
  }
}, {
  code: 1114,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1117,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1135,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 1147,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 1150,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1153,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1168,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightSleet
  }
}, {
  code: 1171,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightSleet
  }
}, {
  code: 1180,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1183,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1186,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1189,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1192,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1195,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1198,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightSleet
  }
}, {
  code: 1201,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightSleet
  }
}, {
  code: 1204,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightRainMix
  }
}, {
  code: 1207,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightRainMix
  }
}, {
  code: 1210,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1213,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1216,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1219,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1222,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1225,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1237,
  icon: {
    day: wi_.WiDayHail,
    night: wi_.WiNightHail
  }
}, {
  code: 1240,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1243,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1246,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightRain
  }
}, {
  code: 1249,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightRainMix
  }
}, {
  code: 1252,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightRainMix
  }
}, {
  code: 1255,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1258,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightSnow
  }
}, {
  code: 1261,
  icon: {
    day: wi_.WiDayHail,
    night: wi_.WiNightHail
  }
}, {
  code: 1264,
  icon: {
    day: wi_.WiDayHail,
    night: wi_.WiNightHail
  }
}, {
  code: 1273,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightThunderstorm
  }
}, {
  code: 1276,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightThunderstorm
  }
}, {
  code: 1279,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightThunderstorm
  }
}, {
  code: 1282,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightThunderstorm
  }
}];
function mapIcon(weatherStatusCode, timeOfDay) {
  const mapping = conditions.find(condition => condition.code === weatherStatusCode);

  if (mapping) {
    if (timeOfDay === "day") {
      return mapping.icon.day;
    }

    if (timeOfDay === "night") {
      return mapping.icon.night;
    }
  }

  return wi_.WiDaySunny;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/widgets/weather/icon.jsx


function Icon({
  condition,
  timeOfDay
}) {
  const IconComponent = mapIcon(condition, timeOfDay);
  return /*#__PURE__*/jsx_runtime_.jsx(IconComponent, {
    className: "w-10 h-10 text-theme-800 dark:text-theme-200"
  });
}

/***/ }),

/***/ 7:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ WeatherApi)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5744);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3688);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function Widget({
  options
}) {
  const {
    t,
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/weather?${new URLSearchParams(_objectSpread({
    lang: i18n.language
  }, options)).toString()}`);

  if (error || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "flex flex-row items-center justify-end",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__.BiError, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "flex flex-col ml-3 text-left",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-sm",
              children: t("widget.api_error")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-xs",
              children: "-"
            })]
          })]
        })
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "flex flex-col items-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__.WiCloudDown, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.updating")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.wait")
          })]
        })]
      })
    });
  }

  const unit = options.units === "metric" ? "celsius" : "fahrenheit";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
    className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "flex flex-row items-center justify-end",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_icon__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          condition: data.current.condition.code,
          timeOfDay: data.current.is_day ? "day" : "night"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-col ml-3 text-left",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("span", {
          className: "text-theme-800 dark:text-theme-200 text-sm",
          children: [options.label && `${options.label}, `, t("common.number", {
            value: options.units === "metric" ? data.current.temp_c : data.current.temp_f,
            style: "unit",
            unit
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
          className: "text-theme-800 dark:text-theme-200 text-xs",
          children: data.current.condition.text
        })]
      })]
    })
  });
}

function WeatherApi({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    0: location,
    1: setLocation
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: requesting,
    1: setRequesting
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  if (!location && options.latitude && options.longitude) {
    setLocation({
      latitude: options.latitude,
      longitude: options.longitude
    });
  }

  const requestLocation = () => {
    setRequesting(true);

    if (false) {}
  }; // if (!requesting && !location) requestLocation();


  if (!location) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("button", {
      type: "button",
      onClick: () => requestLocation(),
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "flex flex-col items-center",
          children: requesting ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationSearching, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200 animate-pulse"
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationDisabled, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.current")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.allow")
          })]
        })]
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Widget, {
    options: _objectSpread(_objectSpread({}, location), options)
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;