"use strict";
exports.id = 7817;
exports.ids = [7817];
exports.modules = {

/***/ 3552:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Icon)
});

// EXTERNAL MODULE: external "react-icons/wi"
var wi_ = __webpack_require__(5744);
;// CONCATENATED MODULE: ./src/utils/weather/openmeteo-condition-map.js
 // see https://open-meteo.com/en/docs

const conditions = [{
  code: 1,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 2,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 3,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 45,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 48,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 51,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 53,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 55,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 56,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 57,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 61,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 63,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 65,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 66,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 67,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 71,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 73,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 75,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 77,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 80,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 81,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 82,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 85,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 86,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 95,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 96,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 99,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}];
function mapIcon(weatherStatusCode, timeOfDay) {
  const mapping = conditions.find(condition => condition.code === weatherStatusCode);

  if (mapping) {
    if (timeOfDay === "day") {
      return mapping.icon.day;
    }

    if (timeOfDay === "night") {
      return mapping.icon.night;
    }
  }

  return wi_.WiDaySunny;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/widgets/openmeteo/icon.jsx


function Icon({
  condition,
  timeOfDay
}) {
  const IconComponent = mapIcon(condition, timeOfDay);
  return /*#__PURE__*/jsx_runtime_.jsx(IconComponent, {
    className: "w-10 h-10 text-theme-800 dark:text-theme-200"
  });
}

/***/ }),

/***/ 7817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ OpenMeteo)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5744);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3552);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function Widget({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/openmeteo?${new URLSearchParams(_objectSpread({}, options)).toString()}`);

  if (error || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "flex flex-row items-center justify-end",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__.BiError, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "flex flex-col ml-3 text-left",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-sm",
              children: t("widget.api_error")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-xs",
              children: "-"
            })]
          })]
        })
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "flex flex-col items-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__.WiCloudDown, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.updating")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.wait")
          })]
        })]
      })
    });
  }

  const unit = options.units === "metric" ? "celsius" : "fahrenheit";
  const timeOfDay = data.current_weather.time > data.daily.sunrise[0] && data.current_weather.time < data.daily.sunset[0] ? "day" : "night";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
    className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "flex flex-row items-center justify-end",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "flex flex-col items-center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_icon__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          condition: data.current_weather.weathercode,
          timeOfDay: timeOfDay
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-col ml-3 text-left",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("span", {
          className: "text-theme-800 dark:text-theme-200 text-sm",
          children: [options.label && `${options.label}, `, t("common.number", {
            value: data.current_weather.temperature,
            style: "unit",
            unit
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
          className: "text-theme-800 dark:text-theme-200 text-xs",
          children: t(`wmo.${data.current_weather.weathercode}-${timeOfDay}`)
        })]
      })]
    })
  });
}

function OpenMeteo({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    0: location,
    1: setLocation
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: requesting,
    1: setRequesting
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  if (!location && options.latitude && options.longitude) {
    setLocation({
      latitude: options.latitude,
      longitude: options.longitude
    });
  }

  const requestLocation = () => {
    setRequesting(true);

    if (false) {}
  }; // if (!requesting && !location) requestLocation();


  if (!location) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("button", {
      type: "button",
      onClick: () => requestLocation(),
      className: "flex flex-col justify-center first:ml-0 ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "flex flex-col items-center",
          children: requesting ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationSearching, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200 animate-pulse"
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationDisabled, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.current")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.allow")
          })]
        })]
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Widget, {
    options: _objectSpread(_objectSpread({}, location), options)
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;