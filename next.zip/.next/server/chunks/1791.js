"use strict";
exports.id = 1791;
exports.ids = [1791];
exports.modules = {

/***/ 4254:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Icon)
});

// EXTERNAL MODULE: external "react-icons/wi"
var wi_ = __webpack_require__(5744);
;// CONCATENATED MODULE: ./src/utils/weather/owm-condition-map.js

const conditions = [{
  code: 200,
  icon: {
    day: wi_.WiDayStormShowers,
    night: wi_.WiNightAltStormShowers
  }
}, {
  code: 201,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 202,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 210,
  icon: {
    day: wi_.WiDayStormShowers,
    night: wi_.WiNightAltStormShowers
  }
}, {
  code: 211,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 212,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 221,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 230,
  icon: {
    day: wi_.WiDayStormShowers,
    night: wi_.WiNightAltStormShowers
  }
}, {
  code: 231,
  icon: {
    day: wi_.WiDayStormShowers,
    night: wi_.WiNightAltStormShowers
  }
}, {
  code: 232,
  icon: {
    day: wi_.WiDayThunderstorm,
    night: wi_.WiNightAltThunderstorm
  }
}, {
  code: 300,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 301,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 302,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 310,
  icon: {
    day: wi_.WiDaySprinkle,
    night: wi_.WiNightAltSprinkle
  }
}, {
  code: 311,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 312,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 313,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 314,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 321,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 500,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 501,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 502,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 503,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 504,
  icon: {
    day: wi_.WiDayRain,
    night: wi_.WiNightAltRain
  }
}, {
  code: 511,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 520,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 521,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 522,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 531,
  icon: {
    day: wi_.WiDayShowers,
    night: wi_.WiNightAltShowers
  }
}, {
  code: 600,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 601,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 602,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 611,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 612,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 613,
  icon: {
    day: wi_.WiDaySleet,
    night: wi_.WiNightAltSleet
  }
}, {
  code: 615,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightAltRainMix
  }
}, {
  code: 616,
  icon: {
    day: wi_.WiDayRainMix,
    night: wi_.WiNightAltRainMix
  }
}, {
  code: 620,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 621,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 622,
  icon: {
    day: wi_.WiDaySnow,
    night: wi_.WiNightAltSnow
  }
}, {
  code: 701,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 711,
  icon: {
    day: wi_.WiSmoke,
    night: wi_.WiSmoke
  }
}, {
  code: 721,
  icon: {
    day: wi_.WiDayHaze,
    night: wi_.WiWindy
  }
}, {
  code: 731,
  icon: {
    day: wi_.WiDust,
    night: wi_.WiDust
  }
}, {
  code: 741,
  icon: {
    day: wi_.WiDayFog,
    night: wi_.WiNightFog
  }
}, {
  code: 751,
  icon: {
    day: wi_.WiDust,
    night: wi_.WiDust
  }
}, {
  code: 761,
  icon: {
    day: wi_.WiSandstorm,
    night: wi_.WiSandstorm
  }
}, {
  code: 762,
  icon: {
    day: wi_.WiDust,
    night: wi_.WiDust
  }
}, {
  code: 771,
  icon: {
    day: wi_.WiStrongWind,
    night: wi_.WiStrongWind
  }
}, {
  code: 781,
  icon: {
    day: wi_.WiTornado,
    night: wi_.WiTornado
  }
}, {
  code: 800,
  icon: {
    day: wi_.WiDaySunny,
    night: wi_.WiNightClear
  }
}, {
  code: 801,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 802,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 803,
  icon: {
    day: wi_.WiDayCloudy,
    night: wi_.WiNightAltCloudy
  }
}, {
  code: 804,
  icon: {
    day: wi_.WiCloudy,
    night: wi_.WiCloudy
  }
}];
function mapIcon(weatherStatusCode, timeOfDay) {
  const mapping = conditions.find(condition => condition.code === weatherStatusCode);

  if (mapping) {
    if (timeOfDay === "day") {
      return mapping.icon.day;
    }

    if (timeOfDay === "night") {
      return mapping.icon.night;
    }
  }

  return wi_.WiDaySunny;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/widgets/openweathermap/icon.jsx


function Icon({
  condition,
  timeOfDay
}) {
  const IconComponent = mapIcon(condition, timeOfDay);
  return /*#__PURE__*/jsx_runtime_.jsx(IconComponent, {
    className: "w-10 h-10 text-theme-800 dark:text-theme-200"
  });
}

/***/ }),

/***/ 1791:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ OpenWeatherMap)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5744);
/* harmony import */ var react_icons_wi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4254);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











function Widget({
  options
}) {
  const {
    t,
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/widgets/openweathermap?${new URLSearchParams(_objectSpread({
    lang: i18n.language
  }, options)).toString()}`);

  if (error || data?.cod === 401 || data?.error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-auto ml-4 mr-2",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "flex flex-row items-center justify-end",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "hidden sm:flex flex-col items-center",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_2__.BiError, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
            className: "flex flex-col ml-3 text-left",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-sm",
              children: t("widget.api_error")
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
              className: "text-theme-800 dark:text-theme-200 text-xs",
              children: "-"
            })]
          })]
        })
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "flex flex-col justify-center first:ml-auto ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "hidden sm:flex flex-col items-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_wi__WEBPACK_IMPORTED_MODULE_3__.WiCloudDown, {
            className: "w-8 h-8 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.updating")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.wait")
          })]
        })]
      })
    });
  }

  const unit = options.units === "metric" ? "celsius" : "fahrenheit";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
    className: "flex flex-col justify-center first:ml-auto ml-2 mr-2",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "flex flex-row items-center justify-end",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
        className: "hidden sm:flex flex-col items-center",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_icon__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
          condition: data.weather[0].id,
          timeOfDay: data.dt > data.sys.sunrise && data.dt < data.sys.sunset ? "day" : "night"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-col ml-3 text-left",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("span", {
          className: "text-theme-800 dark:text-theme-200 text-sm",
          children: [options.label && `${options.label}, `, t("common.number", {
            value: data.main.temp,
            style: "unit",
            unit
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
          className: "text-theme-800 dark:text-theme-200 text-xs",
          children: data.weather[0].description
        })]
      })]
    })
  });
}

function OpenWeatherMap({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
  const {
    0: location,
    1: setLocation
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: requesting,
    1: setRequesting
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  if (!location && options.latitude && options.longitude) {
    setLocation({
      latitude: options.latitude,
      longitude: options.longitude
    });
  }

  const requestLocation = () => {
    setRequesting(true);

    if (false) {}
  }; // if (!requesting && !location) requestLocation();


  if (!location) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("button", {
      type: "button",
      onClick: () => requestLocation(),
      className: "flex flex-col justify-center first:ml-auto ml-4 mr-2",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex flex-row items-center justify-end",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: "hidden sm:flex flex-col items-center",
          children: requesting ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationSearching, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200 animate-pulse"
          }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdLocationDisabled, {
            className: "w-6 h-6 text-theme-800 dark:text-theme-200"
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
          className: "flex flex-col ml-3 text-left",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-sm",
            children: t("weather.current")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
            className: "text-theme-800 dark:text-theme-200 text-xs",
            children: t("weather.allow")
          })]
        })]
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(Widget, {
    options: _objectSpread(_objectSpread({}, location), options)
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;