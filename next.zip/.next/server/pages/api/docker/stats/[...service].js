"use strict";
(() => {
var exports = {};
exports.id = 9630;
exports.ids = [9630];
exports.modules = {

/***/ 4856:
/***/ ((module) => {

module.exports = require("dockerode");

/***/ }),

/***/ 2108:
/***/ ((module) => {

module.exports = require("memory-cache");

/***/ }),

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 7261:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 9987:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var dockerode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4856);
/* harmony import */ var dockerode__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(dockerode__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var utils_config_docker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2156);
/* harmony import */ var utils_logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2330);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_config_docker__WEBPACK_IMPORTED_MODULE_1__, utils_logger__WEBPACK_IMPORTED_MODULE_2__]);
([utils_config_docker__WEBPACK_IMPORTED_MODULE_1__, utils_logger__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const logger = (0,utils_logger__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("dockerStatsService");
async function handler(req, res) {
  const {
    service
  } = req.query;
  const [containerName, containerServer] = service;

  if (!containerName && !containerServer) {
    return res.status(400).send({
      error: "docker query parameters are required"
    });
  }

  try {
    const dockerArgs = (0,utils_config_docker__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(containerServer);
    const docker = new (dockerode__WEBPACK_IMPORTED_MODULE_0___default())(dockerArgs.conn);
    const containers = await docker.listContainers({
      all: true
    }); // bad docker connections can result in a <Buffer ...> object?
    // in any case, this ensures the result is the expected array

    if (!Array.isArray(containers)) {
      return res.status(500).send({
        error: "query failed"
      });
    }

    const containerNames = containers.flatMap(container => container.Names.map(name => name.replace(/^\//, "")));
    const containerExists = containerNames.includes(containerName);

    if (containerExists) {
      const container = docker.getContainer(containerName);
      const stats = await container.stats({
        stream: false
      });
      return res.status(200).json({
        stats
      });
    } // Try with a service deployed in Docker Swarm, if enabled


    if (dockerArgs.swarm) {
      const tasks = await docker.listTasks({
        filters: {
          service: [containerName],
          // A service can have several offline containers, so we only look for an active one.
          "desired-state": ["running"]
        }
      }).catch(() => []); // TODO: Show the result for all replicas/containers?
      // We can only get stats for 'local' containers so try to find one

      const localContainerIDs = containers.map(c => c.Id);
      const task = tasks.find(t => localContainerIDs.includes(t.Status?.ContainerStatus?.ContainerID)) ?? tasks.at(0);
      const taskContainerId = task?.Status?.ContainerStatus?.ContainerID;

      if (taskContainerId) {
        try {
          const container = docker.getContainer(taskContainerId);
          const stats = await container.stats({
            stream: false
          });
          return res.status(200).json({
            stats
          });
        } catch (e) {
          return res.status(200).json({
            error: "Unable to retrieve stats"
          });
        }
      }
    }

    return res.status(404).send({
      error: "not found"
    });
  } catch (e) {
    logger.error(e);
    return res.status(500).send({
      error: {
        message: e?.message ?? "Unknown error"
      }
    });
  }
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5732,2330,2156], () => (__webpack_exec__(9987)));
module.exports = __webpack_exports__;

})();