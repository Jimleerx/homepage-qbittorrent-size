"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 6893:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ BookmarksGroup)
});

// EXTERNAL MODULE: ./src/components/errorboundry.jsx
var errorboundry = __webpack_require__(9193);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/utils/contexts/settings.jsx
var contexts_settings = __webpack_require__(9317);
// EXTERNAL MODULE: ./src/components/resolvedicon.jsx
var resolvedicon = __webpack_require__(8904);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/bookmarks/item.jsx





function Item({
  bookmark
}) {
  const {
    hostname
  } = new URL(bookmark.href);
  const {
    settings
  } = (0,external_react_.useContext)(contexts_settings/* SettingsContext */.J);
  return /*#__PURE__*/jsx_runtime_.jsx("li", {
    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
      href: bookmark.href,
      title: bookmark.name,
      target: bookmark.target ?? settings.target ?? "_blank",
      className: "block w-full text-left cursor-pointer transition-all h-15 mb-3 rounded-md font-medium text-theme-700 dark:text-theme-200 dark:hover:text-theme-300 shadow-md shadow-theme-900/10 dark:shadow-theme-900/20 bg-theme-100/20 hover:bg-theme-300/20 dark:bg-white/5 dark:hover:bg-white/10",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-shrink-0 flex items-center justify-center w-11 bg-theme-500/10 dark:bg-theme-900/50 text-theme-700 hover:text-theme-700 dark:text-theme-200 text-sm font-medium rounded-l-md",
          children: [bookmark.icon && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex-shrink-0 w-5 h-5",
            children: /*#__PURE__*/jsx_runtime_.jsx(resolvedicon/* default */.Z, {
              icon: bookmark.icon,
              alt: bookmark.abbr
            })
          }), !bookmark.icon && bookmark.abbr]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-1 flex items-center justify-between rounded-r-md ",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "flex-1 grow pl-3 py-2 text-xs",
            children: bookmark.name
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "px-2 py-2 truncate text-theme-500 dark:text-theme-300 text-xs",
            children: hostname
          })]
        })]
      })
    })
  }, bookmark.name);
}
;// CONCATENATED MODULE: ./src/components/bookmarks/list.jsx


function List({
  bookmarks
}) {
  return /*#__PURE__*/jsx_runtime_.jsx("ul", {
    className: "mt-3 flex flex-col",
    children: bookmarks.map(bookmark => /*#__PURE__*/jsx_runtime_.jsx(Item, {
      bookmark: bookmark
    }, `${bookmark.name}-${bookmark.href}`))
  });
}
;// CONCATENATED MODULE: ./src/components/bookmarks/group.jsx




function BookmarksGroup({
  group
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex-1",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
      className: "text-theme-800 dark:text-theme-300 text-xl font-medium",
      children: group.name
    }), /*#__PURE__*/jsx_runtime_.jsx(errorboundry/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(List, {
        bookmarks: group.bookmarks
      })
    })]
  }, group.name);
}

/***/ }),

/***/ 9193:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ErrorBoundary)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



class ErrorBoundary extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      errorInfo: null
    };
  }

  componentDidCatch(error, errorInfo) {
    // Catch errors in any components below and re-render with error message
    this.setState({
      error,
      errorInfo
    }); // You can also log error messages to an error reporting service here
    // eslint-disable-next-line no-console

    console.error(error, errorInfo);
  }

  render() {
    const {
      error,
      errorInfo
    } = this.state;

    if (errorInfo) {
      // Error path
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
        className: "inline-block text-sm bg-rose-100 text-rose-900 dark:bg-rose-900 dark:text-rose-100 rounded-md p-2 m-1",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
          className: "font-medium mb-1",
          children: "Something went wrong."
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("details", {
          className: "text-xs font-mono whitespace-pre",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("summary", {
            children: error && error.toString()
          }), errorInfo.componentStack]
        })]
      });
    } // Normally, just render children


    const {
      children
    } = this.props;
    return children;
  }

}

/***/ }),

/***/ 2298:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ QuickLaunch)
/* harmony export */ });
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _resolvedicon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8904);
/* harmony import */ var utils_contexts_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9317);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







function QuickLaunch({
  servicesAndBookmarks,
  searchString,
  setSearchString,
  isOpen,
  close,
  searchProvider
}) {
  const {
    t
  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_0__.useTranslation)();
  const {
    settings
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(utils_contexts_settings__WEBPACK_IMPORTED_MODULE_4__/* .SettingsContext */ .J);
  const {
    searchDescriptions,
    hideVisitURL
  } = settings?.quicklaunch ? settings.quicklaunch : {
    searchDescriptions: false,
    hideVisitURL: false
  };
  const searchField = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
  const {
    0: results,
    1: setResults
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: currentItemIndex,
    1: setCurrentItemIndex
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
  const {
    0: url,
    1: setUrl
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);

  function openCurrentItem(newWindow) {
    const result = results[currentItemIndex];
    window.open(result.href, newWindow ? "_blank" : result.target ?? settings.target ?? "_blank", 'noreferrer');
  }

  const closeAndReset = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(() => {
    close(false);
    setTimeout(() => {
      setSearchString("");
      setCurrentItemIndex(null);
    }, 200); // delay a little for animations
  }, [close, setSearchString, setCurrentItemIndex]);

  function handleSearchChange(event) {
    const rawSearchString = event.target.value.toLowerCase();

    try {
      if (!/.+[.:].+/g.test(rawSearchString)) throw new Error(); // basic test for probably a url

      let urlString = rawSearchString;
      if (urlString.indexOf('http') !== 0) urlString = `https://${rawSearchString}`;
      setUrl(new URL(urlString)); // basic validation
    } catch (e) {
      setUrl(null);
    }

    setSearchString(rawSearchString);
  }

  function handleSearchKeyDown(event) {
    if (!isOpen) return;

    if (event.key === "Escape") {
      closeAndReset();
      event.preventDefault();
    } else if (event.key === "Enter" && results.length) {
      closeAndReset();
      openCurrentItem(event.metaKey);
    } else if (event.key === "ArrowDown" && results[currentItemIndex + 1]) {
      setCurrentItemIndex(currentItemIndex + 1);
      event.preventDefault();
    } else if (event.key === "ArrowUp" && currentItemIndex > 0) {
      setCurrentItemIndex(currentItemIndex - 1);
      event.preventDefault();
    }
  }

  function handleItemHover(event) {
    setCurrentItemIndex(parseInt(event.target?.dataset?.index, 10));
  }

  function handleItemClick(event) {
    closeAndReset();
    openCurrentItem(event.metaKey);
  }

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (searchString.length === 0) setResults([]);else {
      let newResults = servicesAndBookmarks.filter(r => {
        const nameMatch = r.name.toLowerCase().includes(searchString);
        let descriptionMatch;

        if (searchDescriptions) {
          descriptionMatch = r.description?.toLowerCase().includes(searchString);
          r.priority = nameMatch ? 2 * +nameMatch : +descriptionMatch; // eslint-disable-line no-param-reassign
        }

        return nameMatch || descriptionMatch;
      });

      if (searchDescriptions) {
        newResults = newResults.sort((a, b) => b.priority - a.priority);
      }

      if (searchProvider) {
        newResults.push({
          href: searchProvider.url + encodeURIComponent(searchString),
          name: `${searchProvider.name ?? t("quicklaunch.custom")} ${t("quicklaunch.search")} `,
          type: 'search'
        });
      }

      if (!hideVisitURL && url) {
        newResults.unshift({
          href: url.toString(),
          name: `${t("quicklaunch.visit")} URL`,
          type: 'url'
        });
      }

      setResults(newResults);

      if (newResults.length) {
        setCurrentItemIndex(0);
      }
    }
  }, [searchString, servicesAndBookmarks, searchDescriptions, hideVisitURL, searchProvider, url, t]);
  const {
    0: hidden,
    1: setHidden
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    function handleBackdropClick(event) {
      if (event.target?.tagName === "DIV") closeAndReset();
    }

    if (isOpen) {
      searchField.current.focus();
      document.body.addEventListener('click', handleBackdropClick);
      setHidden(false);
    } else {
      document.body.removeEventListener('click', handleBackdropClick);
      searchField.current.blur();
      setTimeout(() => {
        setHidden(true);
      }, 300); // disable on close
    }
  }, [isOpen, closeAndReset]);

  function highlightText(text) {
    const parts = text.split(new RegExp(`(${searchString})`, 'gi')); // eslint-disable-next-line react/no-array-index-key

    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
      children: parts.map((part, i) => part.toLowerCase() === searchString.toLowerCase() ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
        className: "bg-theme-300/10",
        children: part
      }, `${searchString}_${i}`) : part)
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("relative z-20 ease-in-out duration-300 transition-opacity", hidden && !isOpen && "hidden", !hidden && isOpen && "opacity-100", !isOpen && "opacity-0"),
    role: "dialog",
    "aria-modal": "true",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "fixed inset-0 bg-gray-500 bg-opacity-50"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "fixed inset-0 z-20 overflow-y-auto",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: "flex min-h-full min-w-full items-start justify-center text-center",
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("dialog", {
          className: "mt-[10%] min-w-[80%] max-w-[90%] md:min-w-[40%] rounded-md p-0 block font-medium text-theme-700 dark:text-theme-200 dark:hover:text-theme-300 shadow-md shadow-theme-900/10 dark:shadow-theme-900/20 bg-theme-50 dark:bg-theme-800",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("input", {
            placeholder: "Search",
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(results.length > 0 && "rounded-t-md", results.length === 0 && "rounded-md", "w-full p-4 m-0 border-0 border-b border-slate-700 focus:border-slate-700 focus:outline-0 focus:ring-0 text-sm md:text-xl text-theme-700 dark:text-theme-200 bg-theme-60 dark:bg-theme-800"),
            type: "text",
            autoCorrect: "false",
            ref: searchField,
            value: searchString,
            onChange: handleSearchChange,
            onKeyDown: handleSearchKeyDown
          }), results.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("ul", {
            className: "max-h-[60vh] overflow-y-auto m-2",
            children: results.map((r, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("li", {
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("button", {
                type: "button",
                "data-index": i,
                onMouseEnter: handleItemHover,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex flex-row w-full items-center justify-between rounded-md text-sm md:text-xl py-2 px-4 cursor-pointer text-theme-700 dark:text-theme-200", i === currentItemIndex && "bg-theme-300/50 dark:bg-theme-700/50"),
                onClick: handleItemClick,
                children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                  className: "flex flex-row items-center mr-4 pointer-events-none",
                  children: [(r.icon || r.abbr) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                    className: "w-5 text-xs mr-4",
                    children: [r.icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_resolvedicon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                      icon: r.icon
                    }), r.abbr && r.abbr]
                  }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
                    className: "flex flex-col md:flex-row text-left items-baseline mr-4 pointer-events-none",
                    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
                      className: "mr-4",
                      children: r.name
                    }), r.description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
                      className: "text-xs text-theme-600 text-light",
                      children: searchDescriptions && r.priority < 2 ? highlightText(r.description) : r.description
                    })]
                  })]
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
                  className: "text-xs text-theme-600 font-bold pointer-events-none",
                  children: t(`quicklaunch.${r.type ? r.type.toLowerCase() : 'bookmark'}`)
                })]
              })
            }, r.container ?? r.app ?? `${r.name}-${r.href}`))
          })]
        })
      })
    })]
  });
}

/***/ }),

/***/ 8904:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ResolvedIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1608);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_future_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var utils_contexts_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9317);
/* harmony import */ var utils_contexts_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7894);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const iconSetURLs = {
  'mdi': "https://cdn.jsdelivr.net/npm/@mdi/svg@latest/svg/",
  'si': "https://cdn.jsdelivr.net/npm/simple-icons@latest/icons/"
};
function ResolvedIcon({
  icon,
  width = 32,
  height = 32,
  alt = "logo"
}) {
  const {
    settings
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(utils_contexts_settings__WEBPACK_IMPORTED_MODULE_2__/* .SettingsContext */ .J);
  const {
    theme
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(utils_contexts_theme__WEBPACK_IMPORTED_MODULE_3__/* .ThemeContext */ .N); // direct or relative URLs

  if (icon.startsWith("http") || icon.startsWith("/")) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_1___default()), {
      src: `${icon}`,
      width: width,
      height: height,
      style: {
        width,
        height,
        objectFit: "contain",
        maxHeight: "100%",
        maxWidth: "100%"
      },
      alt: alt
    });
  } // check mdi- or si- prefixed icons


  const prefix = icon.split("-")[0];

  if (prefix in iconSetURLs) {
    // get icon source
    const iconName = icon.replace(`${prefix}-`, "").replace(".svg", "");
    const iconSource = `${iconSetURLs[prefix]}${iconName}.svg`;
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      style: {
        width,
        height,
        maxWidth: '100%',
        maxHeight: '100%',
        background: settings.iconStyle === "theme" ? `rgb(var(--color-${theme === "dark" ? 300 : 900}) / var(--tw-text-opacity, 1))` : "linear-gradient(180deg, rgb(var(--color-logo-start)), rgb(var(--color-logo-stop)))",
        mask: `url(${iconSource}) no-repeat center / contain`,
        WebkitMask: `url(${iconSource}) no-repeat center / contain`
      }
    });
  } // fallback to dashboard-icons


  if (icon.endsWith(".svg")) {
    const iconName = icon.replace(".svg", "");
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_1___default()), {
      src: `https://cdn.jsdelivr.net/gh/walkxcode/dashboard-icons/svg/${iconName}.svg`,
      width: width,
      height: height,
      style: {
        width,
        height,
        objectFit: "contain",
        maxHeight: "100%",
        maxWidth: "100%"
      },
      alt: alt
    });
  }

  const iconName = icon.replace(".png", "");
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_1___default()), {
    src: `https://cdn.jsdelivr.net/gh/walkxcode/dashboard-icons/png/${iconName}.png`,
    width: width,
    height: height,
    style: {
      width,
      height,
      objectFit: "contain",
      maxHeight: "100%",
      maxWidth: "100%"
    },
    alt: alt
  });
}

/***/ }),

/***/ 5412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ServicesGroup)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_services_list__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(648);
/* harmony import */ var components_resolvedicon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8904);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_services_list__WEBPACK_IMPORTED_MODULE_1__]);
components_services_list__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function ServicesGroup({
  services,
  layout,
  fiveColumns
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()(layout?.style === "row" ? "basis-full" : "basis-full md:basis-1/2 lg:basis-1/3 xl:basis-1/4", layout?.style !== "row" && fiveColumns ? "3xl:basis-1/5" : "", "flex-1 p-1"),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: "flex select-none items-center",
      children: [layout?.icon && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: "flex-shrink-0 mr-2 w-7 h-7",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_resolvedicon__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
          icon: layout.icon
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
        className: "text-theme-800 dark:text-theme-300 text-xl font-medium",
        children: services.name
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(components_services_list__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      services: services.services,
      layout: layout
    })]
  }, services.name);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5663:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Item)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _status__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4015);
/* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4903);
/* harmony import */ var _ping__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5213);
/* harmony import */ var _kubernetes_status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2542);
/* harmony import */ var widgets_docker_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2613);
/* harmony import */ var widgets_kubernetes_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5889);
/* harmony import */ var utils_contexts_settings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9317);
/* harmony import */ var components_resolvedicon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8904);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_status__WEBPACK_IMPORTED_MODULE_2__, _ping__WEBPACK_IMPORTED_MODULE_4__, _kubernetes_status__WEBPACK_IMPORTED_MODULE_5__, widgets_docker_component__WEBPACK_IMPORTED_MODULE_6__, widgets_kubernetes_component__WEBPACK_IMPORTED_MODULE_7__]);
([_status__WEBPACK_IMPORTED_MODULE_2__, _ping__WEBPACK_IMPORTED_MODULE_4__, _kubernetes_status__WEBPACK_IMPORTED_MODULE_5__, widgets_docker_component__WEBPACK_IMPORTED_MODULE_6__, widgets_kubernetes_component__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function Item({
  service
}) {
  const hasLink = service.href && service.href !== "#";
  const {
    settings
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(utils_contexts_settings__WEBPACK_IMPORTED_MODULE_8__/* .SettingsContext */ .J);
  const showStats = service.showStats === false ? false : settings.showStats;
  const {
    0: statsOpen,
    1: setStatsOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(service.showStats);
  const {
    0: statsClosing,
    1: setStatsClosing
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false); // set stats to closed after 300ms

  const closeStats = () => {
    if (statsOpen) {
      setStatsClosing(true);
      setTimeout(() => {
        setStatsOpen(false);
        setStatsClosing(false);
      }, 300);
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("li", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
      className: `${hasLink ? "cursor-pointer " : " "}transition-all h-15 mb-2 p-1 rounded-md font-medium text-theme-700 dark:text-theme-200 dark:hover:text-theme-300 shadow-md shadow-theme-900/10 dark:shadow-theme-900/20 bg-theme-100/20 hover:bg-theme-300/20 dark:bg-white/5 dark:hover:bg-white/10 relative`,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
        className: "flex select-none",
        children: [service.icon && (hasLink ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
          href: service.href,
          target: service.target ?? settings.target ?? "_blank",
          rel: "noreferrer",
          className: "flex-shrink-0 flex items-center justify-center w-12 ",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_resolvedicon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            icon: service.icon
          })
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
          className: "flex-shrink-0 flex items-center justify-center w-12 ",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(components_resolvedicon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            icon: service.icon
          })
        })), hasLink ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("a", {
          href: service.href,
          target: service.target ?? settings.target ?? "_blank",
          rel: "noreferrer",
          className: "flex-1 flex items-center justify-between rounded-r-md ",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
            className: "flex-1 px-2 py-2 text-sm text-left",
            children: [service.name, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("p", {
              className: "text-theme-500 dark:text-theme-300 text-xs font-light",
              children: service.description
            })]
          })
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
          className: "flex-1 flex items-center justify-between rounded-r-md ",
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
            className: "flex-1 px-2 py-2 text-sm text-left",
            children: [service.name, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("p", {
              className: "text-theme-500 dark:text-theme-300 text-xs font-light",
              children: service.description
            })]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
          className: "absolute top-0 right-0 w-1/2 flex flex-row justify-end gap-2 mr-2",
          children: [service.ping && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
            className: "flex-shrink-0 flex items-center justify-center cursor-pointer",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_ping__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
              service: service
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("span", {
              className: "sr-only",
              children: "Ping status"
            })]
          }), service.container && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("button", {
            type: "button",
            onClick: () => statsOpen ? closeStats() : setStatsOpen(true),
            className: "flex-shrink-0 flex items-center justify-center cursor-pointer",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_status__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
              service: service
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("span", {
              className: "sr-only",
              children: "View container stats"
            })]
          }), service.app && !service.external && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("button", {
            type: "button",
            onClick: () => statsOpen ? closeStats() : setStatsOpen(true),
            className: "flex-shrink-0 flex items-center justify-center cursor-pointer",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_kubernetes_status__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
              service: service
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("span", {
              className: "sr-only",
              children: "View container stats"
            })]
          })]
        })]
      }), service.container && service.server && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()(showStats || statsOpen && !statsClosing ? "max-h-[110px] opacity-100" : " max-h-[0] opacity-0", "w-full overflow-hidden transition-all duration-300 ease-in-out"),
        children: (showStats || statsOpen) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(widgets_docker_component__WEBPACK_IMPORTED_MODULE_6__["default"], {
          service: {
            widget: {
              container: service.container,
              server: service.server
            }
          }
        })
      }), service.app && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()(showStats || statsOpen && !statsClosing ? "max-h-[55px] opacity-100" : " max-h-[0] opacity-0", "w-full overflow-hidden transition-all duration-300 ease-in-out"),
        children: (showStats || statsOpen) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(widgets_kubernetes_component__WEBPACK_IMPORTED_MODULE_7__["default"], {
          service: {
            widget: {
              namespace: service.namespace,
              app: service.app,
              podSelector: service.podSelector
            }
          }
        })
      }), service.widget && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_widget__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        service: service
      })]
    })
  }, service.name);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2542:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ KubernetesStatus)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2021);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__, i18next__WEBPACK_IMPORTED_MODULE_1__]);
([swr__WEBPACK_IMPORTED_MODULE_0__, i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function KubernetesStatus({
  service
}) {
  const podSelectorString = service.podSelector !== undefined ? `podSelector=${service.podSelector}` : "";
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/kubernetes/status/${service.namespace}/${service.app}?${podSelectorString}`);

  if (error) {
    /*#__PURE__*/
    react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      title: (0,i18next__WEBPACK_IMPORTED_MODULE_1__.t)("docker.error"),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-rose-500/80 uppercase",
        children: (0,i18next__WEBPACK_IMPORTED_MODULE_1__.t)("docker.error")
      })
    });
  }

  if (data && data.status === "running") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      title: data.health ?? data.status,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-emerald-500/80 uppercase",
        children: data.health ?? data.status
      })
    });
  }

  if (data && (data.status === "not found" || data.status === "down" || data.status === "partial")) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      title: data.status,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-orange-400/50 dark:text-orange-400/80 uppercase",
        children: data.status
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "text-[8px] font-bold text-black/20 dark:text-white/40 uppercase",
      children: (0,i18next__WEBPACK_IMPORTED_MODULE_1__.t)("docker.unknown")
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 648:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ List)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_services_item__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5663);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_services_item__WEBPACK_IMPORTED_MODULE_1__]);
components_services_item__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const columnMap = ["grid-cols-1 md:grid-cols-1 lg:grid-cols-1", "grid-cols-1 md:grid-cols-1 lg:grid-cols-1", "grid-cols-1 md:grid-cols-2 lg:grid-cols-2", "grid-cols-1 md:grid-cols-2 lg:grid-cols-3", "grid-cols-1 md:grid-cols-2 lg:grid-cols-4", "grid-cols-1 md:grid-cols-2 lg:grid-cols-5", "grid-cols-1 md:grid-cols-2 lg:grid-cols-6", "grid-cols-1 md:grid-cols-2 lg:grid-cols-7", "grid-cols-1 md:grid-cols-2 lg:grid-cols-8"];
function List({
  services,
  layout
}) {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("ul", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()(layout?.style === "row" ? `grid ${columnMap[layout?.columns]} gap-x-2` : "flex flex-col", "mt-3"),
    children: services.map(service => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(components_services_item__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      service: service
    }, service.container ?? service.app ?? service.name))
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Ping)
/* harmony export */ });
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5941);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_1__]);
swr__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Ping({
  service
}) {
  const {
    t
  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_0__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_1__["default"])(`/api/ping?${new URLSearchParams({
    ping: service.ping
  }).toString()}`, {
    refreshInterval: 30000
  });

  if (error) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-rose-500 uppercase",
        children: t("ping.error")
      })
    });
  }

  if (!data) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-black/20 dark:text-white/40 uppercase",
        children: t("ping.ping")
      })
    });
  }

  const statusText = `${service.ping}: HTTP status ${data.status}`;

  if (data.status > 403) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      title: statusText,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-rose-500/80",
        children: data.status
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
    title: statusText,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "text-[8px] font-bold text-emerald-500/80",
      children: t("common.ms", {
        value: data.latency,
        style: "unit",
        unit: "millisecond",
        maximumFractionDigits: 0
      })
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4015:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Status)
/* harmony export */ });
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9709);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_i18next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5941);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_1__]);
swr__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Status({
  service
}) {
  const {
    t
  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_0__.useTranslation)();
  const {
    data,
    error
  } = (0,swr__WEBPACK_IMPORTED_MODULE_1__["default"])(`/api/docker/status/${service.container}/${service.server || ""}`);

  if (error) {
    /*#__PURE__*/
    react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
      title: t("docker.error"),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "text-[8px] font-bold text-rose-500/80 uppercase",
        children: t("docker.error")
      })
    });
  }

  if (data) {
    let statusLabel = "";

    if (data.status?.includes("running")) {
      if (data.health === "starting") {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
          title: t("docker.starting"),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "text-[8px] font-bold text-blue-500/80 uppercase",
            children: t("docker.starting")
          })
        });
      }

      if (data.health === "unhealthy") {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
          title: t("docker.unhealthy"),
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
            className: "text-[8px] font-bold text-orange-400/50 dark:text-orange-400/80 uppercase",
            children: t("docker.unhealthy")
          })
        });
      }

      if (!data.health) {
        statusLabel = data.status.replace("running", t("docker.running"));
      } else {
        statusLabel = data.health === "healthy" ? t("docker.healthy") : data.health;
      }

      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
        title: statusLabel,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "text-[8px] font-bold text-emerald-500/80 uppercase",
          children: statusLabel
        })
      });
    }

    if (data.status === "not found" || data.status === "exited" || data.status?.startsWith("partial")) {
      if (data.status === "not found") statusLabel = t("docker.not_found");else if (data.status === "exited") statusLabel = t("docker.exited");else statusLabel = data.status.replace("partial", t("docker.partial"));
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
        title: statusLabel,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
          className: "text-[8px] font-bold text-orange-400/50 dark:text-orange-400/80 uppercase",
          children: statusLabel
        })
      });
    }
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: "w-auto px-1.5 py-0.5 text-center bg-theme-500/10 dark:bg-theme-900/50 rounded-b-[3px] overflow-hidden",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "text-[8px] font-bold text-black/20 dark:text-white/40 uppercase",
      children: t("docker.unknown")
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Widget)
});

// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(1377);
// EXTERNAL MODULE: ./src/components/errorboundry.jsx
var errorboundry = __webpack_require__(9193);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./src/widgets/components.js

const components = {
  adguard: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9367)]).then(__webpack_require__.bind(__webpack_require__, 9367)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./adguard/component"]
    }
  }),
  audiobookshelf: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7334)]).then(__webpack_require__.bind(__webpack_require__, 7334)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./audiobookshelf/component"]
    }
  }),
  authentik: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3747)]).then(__webpack_require__.bind(__webpack_require__, 3747)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./authentik/component"]
    }
  }),
  autobrr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8239)]).then(__webpack_require__.bind(__webpack_require__, 8239)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./autobrr/component"]
    }
  }),
  bazarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2122)]).then(__webpack_require__.bind(__webpack_require__, 2122)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./bazarr/component"]
    }
  }),
  caddy: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1027)]).then(__webpack_require__.bind(__webpack_require__, 1027)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./caddy/component"]
    }
  }),
  changedetectionio: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9996)]).then(__webpack_require__.bind(__webpack_require__, 9996)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./changedetectionio/component"]
    }
  }),
  channelsdvrserver: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8853)]).then(__webpack_require__.bind(__webpack_require__, 8853)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./channelsdvrserver/component"]
    }
  }),
  cloudflared: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(6752)]).then(__webpack_require__.bind(__webpack_require__, 6752)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./cloudflared/component"]
    }
  }),
  coinmarketcap: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8648)]).then(__webpack_require__.bind(__webpack_require__, 8648)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./coinmarketcap/component"]
    }
  }),
  deluge: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2654)]).then(__webpack_require__.bind(__webpack_require__, 2654)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./deluge/component"]
    }
  }),
  diskstation: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(527)]).then(__webpack_require__.bind(__webpack_require__, 527)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./diskstation/component"]
    }
  }),
  downloadstation: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2825)]).then(__webpack_require__.bind(__webpack_require__, 2825)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./downloadstation/component"]
    }
  }),
  docker: dynamic_default()(() => Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 2613)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./docker/component"]
    }
  }),
  kubernetes: dynamic_default()(() => Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 5889)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./kubernetes/component"]
    }
  }),
  emby: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7613)]).then(__webpack_require__.bind(__webpack_require__, 7613)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./emby/component"]
    }
  }),
  evcc: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(782)]).then(__webpack_require__.bind(__webpack_require__, 782)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./evcc/component"]
    }
  }),
  fileflows: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2978)]).then(__webpack_require__.bind(__webpack_require__, 2978)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./fileflows/component"]
    }
  }),
  flood: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2559)]).then(__webpack_require__.bind(__webpack_require__, 2559)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./flood/component"]
    }
  }),
  freshrss: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2180)]).then(__webpack_require__.bind(__webpack_require__, 2180)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./freshrss/component"]
    }
  }),
  ghostfolio: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1965)]).then(__webpack_require__.bind(__webpack_require__, 1965)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./ghostfolio/component"]
    }
  }),
  gluetun: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(6496)]).then(__webpack_require__.bind(__webpack_require__, 6496)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./gluetun/component"]
    }
  }),
  gotify: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(914)]).then(__webpack_require__.bind(__webpack_require__, 914)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./gotify/component"]
    }
  }),
  grafana: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(816)]).then(__webpack_require__.bind(__webpack_require__, 816)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./grafana/component"]
    }
  }),
  hdhomerun: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1713)]).then(__webpack_require__.bind(__webpack_require__, 1713)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./hdhomerun/component"]
    }
  }),
  homeassistant: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3285)]).then(__webpack_require__.bind(__webpack_require__, 3285)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./homeassistant/component"]
    }
  }),
  homebridge: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4238)]).then(__webpack_require__.bind(__webpack_require__, 4238)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./homebridge/component"]
    }
  }),
  healthchecks: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2241), __webpack_require__.e(6736)]).then(__webpack_require__.bind(__webpack_require__, 6736)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./healthchecks/component"]
    }
  }),
  immich: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8322)]).then(__webpack_require__.bind(__webpack_require__, 8322)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./immich/component"]
    }
  }),
  jackett: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3530)]).then(__webpack_require__.bind(__webpack_require__, 3530)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./jackett/component"]
    }
  }),
  jellyfin: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7613)]).then(__webpack_require__.bind(__webpack_require__, 7613)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./emby/component"]
    }
  }),
  jellyseerr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3602)]).then(__webpack_require__.bind(__webpack_require__, 3602)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./jellyseerr/component"]
    }
  }),
  komga: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(556)]).then(__webpack_require__.bind(__webpack_require__, 556)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./komga/component"]
    }
  }),
  kopia: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4950)]).then(__webpack_require__.bind(__webpack_require__, 4950)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./kopia/component"]
    }
  }),
  lidarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7997)]).then(__webpack_require__.bind(__webpack_require__, 7997)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./lidarr/component"]
    }
  }),
  mastodon: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4109)]).then(__webpack_require__.bind(__webpack_require__, 4109)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./mastodon/component"]
    }
  }),
  medusa: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8752)]).then(__webpack_require__.bind(__webpack_require__, 8752)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./medusa/component"]
    }
  }),
  minecraft: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(680)]).then(__webpack_require__.bind(__webpack_require__, 680)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./minecraft/component"]
    }
  }),
  miniflux: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3730)]).then(__webpack_require__.bind(__webpack_require__, 3730)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./miniflux/component"]
    }
  }),
  mikrotik: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2903)]).then(__webpack_require__.bind(__webpack_require__, 2903)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./mikrotik/component"]
    }
  }),
  moonraker: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1749)]).then(__webpack_require__.bind(__webpack_require__, 1749)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./moonraker/component"]
    }
  }),
  mylar: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2425)]).then(__webpack_require__.bind(__webpack_require__, 2425)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./mylar/component"]
    }
  }),
  navidrome: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3668)]).then(__webpack_require__.bind(__webpack_require__, 3668)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./navidrome/component"]
    }
  }),
  nextcloud: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4136)]).then(__webpack_require__.bind(__webpack_require__, 4136)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./nextcloud/component"]
    }
  }),
  nextdns: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2719)]).then(__webpack_require__.bind(__webpack_require__, 2719)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./nextdns/component"]
    }
  }),
  npm: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8691)]).then(__webpack_require__.bind(__webpack_require__, 8691)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./npm/component"]
    }
  }),
  nzbget: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3901)]).then(__webpack_require__.bind(__webpack_require__, 3901)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./nzbget/component"]
    }
  }),
  octoprint: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9723)]).then(__webpack_require__.bind(__webpack_require__, 9723)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./octoprint/component"]
    }
  }),
  omada: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9114)]).then(__webpack_require__.bind(__webpack_require__, 9114)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./omada/component"]
    }
  }),
  ombi: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4703)]).then(__webpack_require__.bind(__webpack_require__, 4703)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./ombi/component"]
    }
  }),
  opnsense: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2541)]).then(__webpack_require__.bind(__webpack_require__, 2541)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./opnsense/component"]
    }
  }),
  overseerr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8315)]).then(__webpack_require__.bind(__webpack_require__, 8315)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./overseerr/component"]
    }
  }),
  paperlessngx: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9323)]).then(__webpack_require__.bind(__webpack_require__, 9323)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./paperlessngx/component"]
    }
  }),
  pfsense: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(5623)]).then(__webpack_require__.bind(__webpack_require__, 5623)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./pfsense/component"]
    }
  }),
  photoprism: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7277)]).then(__webpack_require__.bind(__webpack_require__, 7277)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./photoprism/component"]
    }
  }),
  proxmoxbackupserver: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(568)]).then(__webpack_require__.bind(__webpack_require__, 568)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./proxmoxbackupserver/component"]
    }
  }),
  pialert: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(134)]).then(__webpack_require__.bind(__webpack_require__, 134)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./pialert/component"]
    }
  }),
  pihole: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9031)]).then(__webpack_require__.bind(__webpack_require__, 9031)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./pihole/component"]
    }
  }),
  plex: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7571)]).then(__webpack_require__.bind(__webpack_require__, 7571)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./plex/component"]
    }
  }),
  portainer: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4552)]).then(__webpack_require__.bind(__webpack_require__, 4552)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./portainer/component"]
    }
  }),
  prometheus: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9811)]).then(__webpack_require__.bind(__webpack_require__, 9811)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./prometheus/component"]
    }
  }),
  prowlarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9514)]).then(__webpack_require__.bind(__webpack_require__, 9514)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./prowlarr/component"]
    }
  }),
  proxmox: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2844)]).then(__webpack_require__.bind(__webpack_require__, 2844)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./proxmox/component"]
    }
  }),
  pterodactyl: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9273)]).then(__webpack_require__.bind(__webpack_require__, 9273)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./pterodactyl/component"]
    }
  }),
  pyload: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(6930)]).then(__webpack_require__.bind(__webpack_require__, 6930)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./pyload/component"]
    }
  }),
  qbittorrent: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7429)]).then(__webpack_require__.bind(__webpack_require__, 7429)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./qbittorrent/component"]
    }
  }),
  qnap: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1490)]).then(__webpack_require__.bind(__webpack_require__, 1490)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./qnap/component"]
    }
  }),
  radarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1239)]).then(__webpack_require__.bind(__webpack_require__, 1239)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./radarr/component"]
    }
  }),
  readarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3652)]).then(__webpack_require__.bind(__webpack_require__, 3652)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./readarr/component"]
    }
  }),
  rutorrent: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3689)]).then(__webpack_require__.bind(__webpack_require__, 3689)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./rutorrent/component"]
    }
  }),
  sabnzbd: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9319)]).then(__webpack_require__.bind(__webpack_require__, 9319)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./sabnzbd/component"]
    }
  }),
  scrutiny: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(5818)]).then(__webpack_require__.bind(__webpack_require__, 5818)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./scrutiny/component"]
    }
  }),
  sonarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(116)]).then(__webpack_require__.bind(__webpack_require__, 116)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./sonarr/component"]
    }
  }),
  speedtest: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2451)]).then(__webpack_require__.bind(__webpack_require__, 2451)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./speedtest/component"]
    }
  }),
  strelaysrv: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(2571)]).then(__webpack_require__.bind(__webpack_require__, 2571)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./strelaysrv/component"]
    }
  }),
  tailscale: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1686)]).then(__webpack_require__.bind(__webpack_require__, 1686)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./tailscale/component"]
    }
  }),
  tautulli: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(66)]).then(__webpack_require__.bind(__webpack_require__, 66)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./tautulli/component"]
    }
  }),
  tdarr: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(5318)]).then(__webpack_require__.bind(__webpack_require__, 5318)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./tdarr/component"]
    }
  }),
  traefik: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(3296)]).then(__webpack_require__.bind(__webpack_require__, 3296)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./traefik/component"]
    }
  }),
  transmission: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8442)]).then(__webpack_require__.bind(__webpack_require__, 8442)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./transmission/component"]
    }
  }),
  tubearchivist: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4310)]).then(__webpack_require__.bind(__webpack_require__, 4310)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./tubearchivist/component"]
    }
  }),
  truenas: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(4734)]).then(__webpack_require__.bind(__webpack_require__, 4734)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./truenas/component"]
    }
  }),
  unifi: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(8977)]).then(__webpack_require__.bind(__webpack_require__, 8977)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./unifi/component"]
    }
  }),
  unmanic: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7288)]).then(__webpack_require__.bind(__webpack_require__, 7288)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./unmanic/component"]
    }
  }),
  uptimekuma: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(9384)]).then(__webpack_require__.bind(__webpack_require__, 9384)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./uptimekuma/component"]
    }
  }),
  watchtower: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1695)]).then(__webpack_require__.bind(__webpack_require__, 1695)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./watchtower/component"]
    }
  }),
  whatsupdocker: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1118)]).then(__webpack_require__.bind(__webpack_require__, 1118)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./whatsupdocker/component"]
    }
  }),
  xteve: dynamic_default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(1178)]).then(__webpack_require__.bind(__webpack_require__, 1178)), {
    loadableGenerated: {
      modules: ["..\\widgets\\components.js -> " + "./xteve/component"]
    }
  })
};
/* harmony default export */ const widgets_components = (components);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/services/widget.jsx




function Widget({
  service
}) {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  const ServiceWidget = widgets_components[service.widget.type];

  if (ServiceWidget) {
    return /*#__PURE__*/jsx_runtime_.jsx(errorboundry/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(ServiceWidget, {
        service: service
      })
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "bg-theme-200/50 dark:bg-theme-900/20 rounded m-1 flex-1 flex flex-col items-center justify-center p-1",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "font-thin text-sm",
      children: t("widget.missing_type", {
        type: service.widget.type
      })
    })
  });
}

/***/ }),

/***/ 403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Block)
/* harmony export */ });
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




function Block({
  value,
  label
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_0__.useTranslation)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("bg-theme-200/50 dark:bg-theme-900/20 rounded m-1 flex-1 flex flex-col items-center justify-center text-center p-1", value === undefined ? "animate-pulse" : ""),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "font-thin text-sm",
      children: value === undefined || value === null ? "-" : value
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "font-bold text-xs uppercase",
      children: t(label)
    })]
  });
}

/***/ }),

/***/ 7816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Container)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(9709);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/services/widget/error.jsx





function displayError(error) {
  return JSON.stringify(error[1] ? error[1] : error, null, 4);
}

function displayData(data) {
  return data.type === 'Buffer' ? Buffer.from(data).toString() : JSON.stringify(data, 4);
}

function Error({
  error: err
}) {
  const {
    t
  } = (0,external_react_i18next_.useTranslation)();
  const {
    error
  } = err?.data ?? {
    error: err
  };
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("details", {
    className: "px-1 pb-1",
    children: [/*#__PURE__*/jsx_runtime_.jsx("summary", {
      className: "block text-center mt-1 mb-0 mx-auto p-3 rounded bg-rose-900/80 hover:bg-rose-900/95 text-theme-900 cursor-pointer",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-center text-xs font-bold",
        children: [/*#__PURE__*/jsx_runtime_.jsx(io5_.IoAlertCircle, {
          className: "mr-1 w-5 h-5"
        }), t("widget.api_error"), " ", error.message && t("widget.information")]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "bg-white dark:bg-theme-200/50 mt-2 rounded text-rose-900 text-xs font-mono whitespace-pre-wrap break-all",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
        className: "p-4",
        children: [error.message && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "text-black",
            children: [t("widget.api_error"), ":"]
          }), " ", error.message]
        }), error.url && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "mt-2",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "text-black",
            children: [t("widget.url"), ":"]
          }), " ", error.url]
        }), error.rawError && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "mt-2",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "text-black",
            children: [t("widget.raw_error"), ":"]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "ml-2",
            children: displayError(error.rawError)
          })]
        }), error.data && /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
          className: "mt-2",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "text-black",
            children: [t("widget.response_data"), ":"]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "ml-2",
            children: displayData(error.data)
          })]
        })]
      })
    })]
  });
}
// EXTERNAL MODULE: ./src/utils/contexts/settings.jsx
var contexts_settings = __webpack_require__(9317);
;// CONCATENATED MODULE: ./src/components/services/widget/container.jsx




function Container({
  error = false,
  children,
  service
}) {
  const {
    settings
  } = (0,external_react_.useContext)(contexts_settings/* SettingsContext */.J);

  if (error) {
    if (settings.hideErrors || service.widget.hide_errors) {
      return null;
    }

    return /*#__PURE__*/jsx_runtime_.jsx(Error, {
      service: service,
      error: error
    });
  }

  let visibleChildren = children;
  const fields = service?.widget?.fields;
  const type = service?.widget?.type;

  if (fields && type) {
    // if the field contains a "." then it most likely contains a common loc value
    // logic now allows a fields array that can look like:
    // fields: [ "resources.cpu", "resources.mem", "field"]
    // or even
    // fields: [ "resources.cpu", "widget_type.field" ]
    visibleChildren = children?.filter(child => fields.some(field => {
      let fullField = field;

      if (!field.includes(".")) {
        fullField = `${type}.${field}`;
      }

      return fullField === child?.props?.label;
    }));
  }

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "relative flex flex-row w-full",
    children: visibleChildren
  });
}

/***/ }),

/***/ 7578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Revalidate)
/* harmony export */ });
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);


function Revalidate() {
  const revalidate = () => {
    fetch("/api/revalidate").then(res => {
      if (res.ok) {
        window.location.reload();
      }
    });
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "rounded-full flex align-middle self-center mr-3",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_0__.MdRefresh, {
      onClick: () => revalidate(),
      className: "text-theme-800 dark:text-theme-200 w-6 h-6 cursor-pointer"
    })
  });
}

/***/ }),

/***/ 8874:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search),
/* harmony export */   "getStoredProvider": () => (/* binding */ getStoredProvider),
/* harmony export */   "searchProviders": () => (/* binding */ searchProviders)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(764);
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_si__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1185);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_4__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const searchProviders = {
  google: {
    name: "Google",
    url: "https://www.google.com/search?q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiGoogle
  },
  duckduckgo: {
    name: "DuckDuckGo",
    url: "https://duckduckgo.com/?q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiDuckduckgo
  },
  bing: {
    name: "Bing",
    url: "https://www.bing.com/search?q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiMicrosoftbing
  },
  baidu: {
    name: "Baidu",
    url: "https://www.baidu.com/s?wd=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiBaidu
  },
  brave: {
    name: "Brave",
    url: "https://search.brave.com/search?q=",
    icon: react_icons_si__WEBPACK_IMPORTED_MODULE_3__.SiBrave
  },
  custom: {
    name: "Custom",
    url: false,
    icon: react_icons_fi__WEBPACK_IMPORTED_MODULE_2__.FiSearch
  }
};

function getAvailableProviderIds(options) {
  if (options.provider && Array.isArray(options.provider)) {
    return Object.keys(searchProviders).filter(value => options.provider.includes(value));
  }

  if (options.provider && searchProviders[options.provider]) {
    return [options.provider];
  }

  return null;
}

const localStorageKey = "search-name";
function getStoredProvider() {
  if (false) {}

  return null;
}
function Search({
  options
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const availableProviderIds = getAvailableProviderIds(options);
  const {
    0: query,
    1: setQuery
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: selectedProvider,
    1: setSelectedProvider
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(searchProviders[availableProviderIds[0] ?? searchProviders.google]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const storedProvider = getStoredProvider();
    let storedProviderKey = null;
    storedProviderKey = Object.keys(searchProviders).find(pkey => searchProviders[pkey] === storedProvider);

    if (storedProvider && availableProviderIds.includes(storedProviderKey)) {
      setSelectedProvider(storedProvider);
    }
  }, [availableProviderIds]);

  if (!availableProviderIds) {
    return null;
  }

  function handleSubmit(event) {
    const q = encodeURIComponent(query);
    const {
      url
    } = selectedProvider;

    if (url) {
      window.open(`${url}${q}`, options.target || "_blank");
    } else {
      window.open(`${options.url}${q}`, options.target || "_blank");
    }

    event.preventDefault();
    event.target.reset();
    setQuery("");
  }

  const onChangeProvider = provider => {
    setSelectedProvider(provider);
    localStorage.setItem(localStorageKey, provider.name);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("form", {
    className: "flex-col relative h-8 my-4 min-w-fit grow first:ml-0 ml-4",
    onSubmit: handleSubmit,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
      className: "flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none w-full text-theme-800 dark:text-white"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("input", {
      type: "text",
      className: " overflow-hidden w-full h-full rounded-md text-xs text-theme-900 dark:text-white placeholder-theme-900 dark:placeholder-white/80 bg-white/50 dark:bg-white/10 focus:ring-theme-500 dark:focus:ring-white/50 focus:border-theme-500 dark:focus:border-white/50 border border-theme-300 dark:border-theme-200/50",
      placeholder: t("search.placeholder"),
      onChange: s => setQuery(s.currentTarget.value),
      required: true,
      autoCapitalize: "off",
      autoCorrect: "off",
      autoComplete: "off" // eslint-disable-next-line jsx-a11y/no-autofocus
      ,
      autoFocus: options.focus
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__.Listbox, {
      as: "div",
      value: selectedProvider,
      onChange: onChangeProvider,
      className: "relative text-left",
      disabled: availableProviderIds?.length === 1,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__.Listbox.Button, {
          className: " absolute right-0.5 bottom-0.5 rounded-r-md px-4 py-2 border-1 text-white font-medium text-sm bg-theme-600/40 dark:bg-white/10 focus:ring-theme-500 dark:focus:ring-white/50",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(selectedProvider.icon, {
            className: "text-white w-3 h-3"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("span", {
            className: "sr-only",
            children: t("search.search")
          })]
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__.Transition, {
        as: react__WEBPACK_IMPORTED_MODULE_0__.Fragment,
        enter: "transition ease-out duration-100",
        enterFrom: "transform opacity-0 scale-95",
        enterTo: "transform opacity-100 scale-100",
        leave: "transition ease-in duration-75",
        leaveFrom: "transform opacity-100 scale-100",
        leaveTo: "transform opacity-0 scale-95",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__.Listbox.Options, {
          className: "absolute right-0 z-10 mt-1 origin-top-right rounded-md  bg-theme-100 dark:bg-theme-600 shadow-lg  ring-1 ring-black ring-opacity-5 focus:outline-none",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
            className: "flex flex-col",
            children: availableProviderIds.map(providerId => {
              const p = searchProviders[providerId];
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_4__.Listbox.Option, {
                value: p,
                as: react__WEBPACK_IMPORTED_MODULE_0__.Fragment,
                children: ({
                  active
                }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("li", {
                  className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("rounded-md cursor-pointer", active ? "bg-theme-600/10 dark:bg-white/10 dark:text-gray-900" : "dark:text-gray-100"),
                  children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(p.icon, {
                    className: "h-4 w-4 mx-4 my-2"
                  })
                })
              }, providerId);
            })
          })
        })
      })]
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Widget)
/* harmony export */ });
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_errorboundry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9193);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const widgetMappings = {
  weatherapi: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 7).then(__webpack_require__.bind(__webpack_require__, 7)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/weather/weather"]
    }
  }),
  openweathermap: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 1791).then(__webpack_require__.bind(__webpack_require__, 1791)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/openweathermap/weather"]
    }
  }),
  resources: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 8546).then(__webpack_require__.bind(__webpack_require__, 8546)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/resources/resources"]
    }
  }),
  search: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 8874)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/search/search"]
    }
  }),
  greeting: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 1590).then(__webpack_require__.bind(__webpack_require__, 1590)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/greeting/greeting"]
    }
  }),
  datetime: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 2767).then(__webpack_require__.bind(__webpack_require__, 2767)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/datetime/datetime"]
    }
  }),
  logo: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 6776).then(__webpack_require__.bind(__webpack_require__, 6776)), {
    ssr: false,
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/logo/logo"]
    }
  }),
  unifi_console: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => Promise.all(/* import() */[__webpack_require__.e(4582), __webpack_require__.e(7517)]).then(__webpack_require__.bind(__webpack_require__, 7517)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/unifi_console/unifi_console"]
    }
  }),
  glances: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 6007).then(__webpack_require__.bind(__webpack_require__, 6007)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/glances/glances"]
    }
  }),
  openmeteo: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 7817).then(__webpack_require__.bind(__webpack_require__, 7817)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/openmeteo/openmeteo"]
    }
  }),
  longhorn: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 5595).then(__webpack_require__.bind(__webpack_require__, 5595)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/longhorn/longhorn"]
    }
  }),
  kubernetes: next_dynamic__WEBPACK_IMPORTED_MODULE_0___default()(() => __webpack_require__.e(/* import() */ 864).then(__webpack_require__.bind(__webpack_require__, 864)), {
    loadableGenerated: {
      modules: ["..\\components\\widgets\\widget.jsx -> " + "components/widgets/kubernetes/kubernetes"]
    }
  })
};
function Widget({
  widget
}) {
  const InfoWidget = widgetMappings[widget.type];

  if (InfoWidget) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(components_errorboundry__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(InfoWidget, {
        options: widget.options
      })
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: "flex-none flex flex-row items-center justify-center",
    children: ["Missing ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("strong", {
      children: widget.type
    })]
  });
}

/***/ }),

/***/ 6243:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Wrapper),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7281);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5460);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_services_group__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5412);
/* harmony import */ var components_bookmarks_group__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6893);
/* harmony import */ var components_widgets_widget__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(555);
/* harmony import */ var components_toggles_revalidate__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7578);
/* harmony import */ var utils_logger__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8204);
/* harmony import */ var utils_hooks_window_focus__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5826);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9365);
/* harmony import */ var utils_contexts_color__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2112);
/* harmony import */ var utils_contexts_theme__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7894);
/* harmony import */ var utils_contexts_settings__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9317);
/* harmony import */ var utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3093);
/* harmony import */ var components_errorboundry__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9193);
/* harmony import */ var utils_styles_themes__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8726);
/* harmony import */ var components_quicklaunch__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2298);
/* harmony import */ var components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8874);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__, components_services_group__WEBPACK_IMPORTED_MODULE_8__, utils_logger__WEBPACK_IMPORTED_MODULE_12__, utils_config_config__WEBPACK_IMPORTED_MODULE_14__, utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__, components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__]);
([swr__WEBPACK_IMPORTED_MODULE_0__, components_services_group__WEBPACK_IMPORTED_MODULE_8__, utils_logger__WEBPACK_IMPORTED_MODULE_12__, utils_config_config__WEBPACK_IMPORTED_MODULE_14__, utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__, components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
const _excluded = ["providers"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/* eslint-disable react/no-array-index-key */


























const ThemeToggle = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(() => __webpack_require__.e(/* import() */ 8085).then(__webpack_require__.bind(__webpack_require__, 8085)), {
  ssr: false,
  loadableGenerated: {
    modules: ["index.jsx -> " + "components/toggles/theme"]
  }
});
const ColorToggle = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(() => __webpack_require__.e(/* import() */ 8642).then(__webpack_require__.bind(__webpack_require__, 8642)), {
  ssr: false,
  loadableGenerated: {
    modules: ["index.jsx -> " + "components/toggles/color"]
  }
});
const Version = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(() => __webpack_require__.e(/* import() */ 1281).then(__webpack_require__.bind(__webpack_require__, 1281)), {
  ssr: false,
  loadableGenerated: {
    modules: ["index.jsx -> " + "components/version"]
  }
});
const rightAlignedWidgets = ["weatherapi", "openweathermap", "weather", "openmeteo", "search", "datetime"];
async function getStaticProps() {
  let logger;

  try {
    logger = (0,utils_logger__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)("index");

    const _getSettings = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_14__/* .getSettings */ .Gw)(),
          {
      providers
    } = _getSettings,
          settings = _objectWithoutProperties(_getSettings, _excluded);

    const services = await (0,utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__/* .servicesResponse */ .bh)();
    const bookmarks = await (0,utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__/* .bookmarksResponse */ .IY)();
    const widgets = await (0,utils_config_api_response__WEBPACK_IMPORTED_MODULE_18__/* .widgetsResponse */ .a5)();
    return {
      props: _objectSpread({
        initialSettings: settings,
        fallback: {
          "/api/services": services,
          "/api/bookmarks": bookmarks,
          "/api/widgets": widgets,
          "/api/hash": false
        }
      }, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_7__.serverSideTranslations)(settings.language ?? "en"))
    };
  } catch (e) {
    if (logger) {
      logger.error(e);
    }

    return {
      props: _objectSpread({
        initialSettings: {},
        fallback: {
          "/api/services": [],
          "/api/bookmarks": [],
          "/api/widgets": [],
          "/api/hash": false
        }
      }, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_7__.serverSideTranslations)("en"))
    };
  }
}

function Index({
  initialSettings,
  fallback
}) {
  const windowFocused = (0,utils_hooks_window_focus__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
  const {
    0: stale,
    1: setStale
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
  const {
    data: errorsData
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])("/api/validate");
  const {
    data: hashData,
    mutate: mutateHash
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])("/api/hash");
  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(() => {
    if (windowFocused) {
      mutateHash();
    }
  }, [windowFocused, mutateHash]);
  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(() => {
    if (hashData) {
      if (false) {}
    }
  }, [hashData]);

  if (stale) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
      className: "flex items-center justify-center h-screen",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        className: "w-24 h-24 border-2 border-theme-400 border-solid rounded-full animate-spin border-t-transparent"
      })
    });
  }

  if (errorsData && errorsData.length > 0) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
      className: "w-full h-screen container m-auto justify-center p-10 pointer-events-none",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        className: "flex flex-col",
        children: errorsData.map((error, i) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
          className: "basis-1/2 bg-theme-500 dark:bg-theme-600 text-theme-600 dark:text-theme-300 m-2 rounded-md font-mono shadow-md border-4 border-transparent",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
            className: "bg-amber-200 text-amber-800 dark:text-amber-200 dark:bg-amber-800 p-2 rounded-md font-bold",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__.BiError, {
              className: "float-right w-6 h-6"
            }), error.config]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
            className: "p-2 text-theme-100 dark:text-theme-200",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("pre", {
              className: "opacity-50 font-bold pb-2",
              children: error.reason
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("pre", {
              className: "text-sm",
              children: error.mark.snippet
            })]
          })]
        }, i))
      })
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(swr__WEBPACK_IMPORTED_MODULE_0__.SWRConfig, {
    value: {
      fallback,
      fetcher: (resource, init) => fetch(resource, init).then(res => res.json())
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_errorboundry__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(Home, {
        initialSettings: initialSettings
      })
    })
  });
}

const headerStyles = {
  boxed: "m-4 mb-0 sm:m-8 sm:mb-0 rounded-md shadow-md shadow-theme-900/10 dark:shadow-theme-900/20 bg-theme-100/20 dark:bg-white/5 p-3",
  underlined: "m-4 mb-0 sm:m-8 sm:mb-1 border-b-2 pb-4 border-theme-800 dark:border-theme-200/50",
  clean: "m-4 mb-0 sm:m-8 sm:mb-0"
};

function Home({
  initialSettings
}) {
  const {
    i18n
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
  const {
    theme,
    setTheme
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(utils_contexts_theme__WEBPACK_IMPORTED_MODULE_16__/* .ThemeContext */ .N);
  const {
    color,
    setColor
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(utils_contexts_color__WEBPACK_IMPORTED_MODULE_15__/* .ColorContext */ .d);
  const {
    settings,
    setSettings
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(utils_contexts_settings__WEBPACK_IMPORTED_MODULE_17__/* .SettingsContext */ .J);
  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(() => {
    setSettings(initialSettings);
  }, [initialSettings, setSettings]);
  const {
    data: services
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])("/api/services");
  const {
    data: bookmarks
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])("/api/bookmarks");
  const {
    data: widgets
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])("/api/widgets");
  const servicesAndBookmarks = [...services.map(sg => sg.services).flat(), ...bookmarks.map(bg => bg.bookmarks).flat()];
  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(() => {
    if (settings.language) {
      i18n.changeLanguage(settings.language);
    }

    if (settings.theme && theme !== settings.theme) {
      setTheme(settings.theme);
    }

    if (settings.color && color !== settings.color) {
      setColor(settings.color);
    }
  }, [i18n, settings, color, setColor, theme, setTheme]);
  const {
    0: searching,
    1: setSearching
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
  const {
    0: searchString,
    1: setSearchString
  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
  let searchProvider = null;
  const searchWidget = Object.values(widgets).find(w => w.type === "search");

  if (searchWidget) {
    if (Array.isArray(searchWidget.options?.provider)) {
      // if search provider is a list, try to retrieve from localstorage, fall back to the first
      searchProvider = (0,components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__.getStoredProvider)() ?? components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__.searchProviders[searchWidget.options.provider[0]];
    } else if (searchWidget.options?.provider === 'custom') {
      searchProvider = {
        url: searchWidget.options.url
      };
    } else {
      searchProvider = components_widgets_search_search__WEBPACK_IMPORTED_MODULE_22__.searchProviders[searchWidget.options?.provider];
    }
  }

  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === "BODY") {
        if (String.fromCharCode(e.keyCode).match(/(\w|\s)/g) && !(e.altKey || e.ctrlKey || e.metaKey || e.shiftKey)) {
          setSearching(true);
        } else if (e.key === "Escape") {
          setSearchString("");
          setSearching(false);
        }
      }
    }

    document.addEventListener('keydown', handleKeyDown);
    return function cleanup() {
      document.removeEventListener('keydown', handleKeyDown);
    };
  });
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("title", {
        children: initialSettings.title || "Homepage"
      }), initialSettings.base && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("base", {
        href: initialSettings.base
      }), initialSettings.favicon ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "apple-touch-icon",
          sizes: "180x180",
          href: initialSettings.favicon
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "icon",
          href: initialSettings.favicon
        })]
      }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "apple-touch-icon",
          sizes: "180x180",
          href: "/apple-touch-icon.png?v=4"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "shortcut icon",
          href: "/homepage.ico"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "icon",
          type: "image/png",
          sizes: "32x32",
          href: "/favicon-32x32.png?v=4"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("link", {
          rel: "icon",
          type: "image/png",
          sizes: "16x16",
          href: "/favicon-16x16.png?v=4"
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("meta", {
        name: "msapplication-TileColor",
        content: utils_styles_themes__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z[initialSettings.color || "slate"][initialSettings.theme || "dark"]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("meta", {
        name: "theme-color",
        content: utils_styles_themes__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z[initialSettings.color || "slate"][initialSettings.theme || "dark"]
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
      className: "relative container m-auto flex flex-col justify-between z-10 h-full",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex flex-row flex-wrap  justify-between", headerStyles[initialSettings.headerStyle || "underlined"]),
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_quicklaunch__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
          servicesAndBookmarks: servicesAndBookmarks,
          searchString: searchString,
          setSearchString: setSearchString,
          isOpen: searching,
          close: setSearching,
          searchProvider: settings.quicklaunch?.hideInternetSearch ? null : searchProvider
        }), widgets && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.Fragment, {
          children: [widgets.filter(widget => !rightAlignedWidgets.includes(widget.type)).map((widget, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_widgets_widget__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            widget: widget
          }, i)), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
            className: "m-auto sm:ml-2 flex flex-wrap grow sm:basis-auto justify-between md:justify-end",
            children: widgets.filter(widget => rightAlignedWidgets.includes(widget.type)).map((widget, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_widgets_widget__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
              widget: widget
            }, i))
          })]
        })]
      }), services?.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        className: "flex flex-wrap p-4 sm:p-8 sm:pt-4 items-start pb-2",
        children: services.map(group => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_services_group__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
          services: group,
          layout: initialSettings.layout?.[group.name],
          fiveColumns: settings.fiveColumns
        }, group.name))
      }), bookmarks?.length > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        className: `grow flex flex-wrap pt-0 p-4 sm:p-8 gap-2 grid-cols-1 lg:grid-cols-2 lg:grid-cols-${Math.min(6, bookmarks.length)}`,
        children: bookmarks.map(group => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_bookmarks_group__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
          group: group
        }, group.name))
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsxs)("div", {
        className: "flex p-8 pb-0 w-full justify-end",
        children: [!initialSettings?.color && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(ColorToggle, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(components_toggles_revalidate__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}), !initialSettings?.theme && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(ThemeToggle, {})]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        className: "flex p-8 pt-4 w-full justify-end",
        children: !initialSettings?.hideVersion && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(Version, {})
      })]
    })]
  });
}

function Wrapper({
  initialSettings,
  fallback
}) {
  const wrappedStyle = {};
  let backgroundBlur = false;
  let backgroundSaturate = false;
  let backgroundBrightness = false;

  if (initialSettings && initialSettings.background) {
    let opacity = initialSettings.backgroundOpacity ?? 1;
    let backgroundImage = initialSettings.background;

    if (typeof initialSettings.background === 'object') {
      backgroundImage = initialSettings.background.image;
      backgroundBlur = initialSettings.background.blur !== undefined;
      backgroundSaturate = initialSettings.background.saturate !== undefined;
      backgroundBrightness = initialSettings.background.brightness !== undefined;
      if (initialSettings.background.opacity !== undefined) opacity = initialSettings.background.opacity / 100;
    }

    const opacityValue = 1 - opacity;
    wrappedStyle.backgroundImage = `
      linear-gradient(
        rgb(var(--bg-color) / ${opacityValue}),
        rgb(var(--bg-color) / ${opacityValue})
      ),
      url(${backgroundImage})`;
    wrappedStyle.backgroundPosition = "center";
    wrappedStyle.backgroundSize = "cover";
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
    id: "page_wrapper",
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("relative", initialSettings.theme && initialSettings.theme, initialSettings.color && `theme-${initialSettings.color}`),
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
      id: "page_container",
      className: "fixed overflow-auto w-full h-full bg-theme-50 dark:bg-theme-800 transition-all",
      style: wrappedStyle,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx("div", {
        id: "inner_wrapper",
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()('fixed overflow-auto w-full h-full', backgroundBlur && `backdrop-blur${initialSettings.background.blur.length ? '-' : ""}${initialSettings.background.blur}`, backgroundSaturate && `backdrop-saturate-${initialSettings.background.saturate}`, backgroundBrightness && `backdrop-brightness-${initialSettings.background.brightness}`),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_23__.jsx(Index, {
          initialSettings: initialSettings,
          fallback: fallback
        })
      })
    })
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IY": () => (/* binding */ bookmarksResponse),
/* harmony export */   "a5": () => (/* binding */ widgetsResponse),
/* harmony export */   "bh": () => (/* binding */ servicesResponse)
/* harmony export */ });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(626);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9365);
/* harmony import */ var utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7771);
/* harmony import */ var utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1581);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__, utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__, utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_5__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__, utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__, utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/* eslint-disable no-console */






/**
 * Compares services by weight then by name.
 */

function compareServices(service1, service2) {
  const comp = service1.weight - service2.weight;

  if (comp !== 0) {
    return comp;
  }

  return service1.name.localeCompare(service2.name);
}

async function bookmarksResponse() {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP)("bookmarks.yaml");
  const bookmarksYaml = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "config", "bookmarks.yaml");
  const rawFileContents = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(bookmarksYaml, "utf8");
  const fileContents = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* .substituteEnvironmentVars */ .AI)(rawFileContents);
  const bookmarks = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(fileContents);
  if (!bookmarks) return []; // map easy to write YAML objects into easy to consume JS arrays

  const bookmarksArray = bookmarks.map(group => ({
    name: Object.keys(group)[0],
    bookmarks: group[Object.keys(group)[0]].map(entries => _objectSpread({
      name: Object.keys(entries)[0]
    }, entries[Object.keys(entries)[0]][0]))
  }));
  return bookmarksArray;
}
async function widgetsResponse() {
  let configuredWidgets;

  try {
    configuredWidgets = (0,utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_5__/* .cleanWidgetGroups */ .qz)(await (0,utils_config_widget_helpers__WEBPACK_IMPORTED_MODULE_5__/* .widgetsFromConfig */ .uN)());
  } catch (e) {
    console.error("Failed to load widgets, please check widgets.yaml for errors or remove example entries.");
    if (e) console.error(e);
    configuredWidgets = [];
  }

  return configuredWidgets;
}
async function servicesResponse() {
  let discoveredDockerServices;
  let discoveredKubernetesServices;
  let configuredServices;
  let initialSettings;

  try {
    discoveredDockerServices = (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .cleanServiceGroups */ .gr)(await (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .servicesFromDocker */ .kr)());

    if (discoveredDockerServices?.length === 0) {
      console.debug("No containers were found with homepage labels.");
    }
  } catch (e) {
    console.error("Failed to discover services, please check docker.yaml for errors or remove example entries.");
    if (e) console.error(e.toString());
    discoveredDockerServices = [];
  }

  try {
    discoveredKubernetesServices = (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .cleanServiceGroups */ .gr)(await (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .servicesFromKubernetes */ .iP)());
  } catch (e) {
    console.error("Failed to discover services, please check kubernetes.yaml for errors or remove example entries.");
    if (e) console.error(e.toString());
    discoveredKubernetesServices = [];
  }

  try {
    configuredServices = (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .cleanServiceGroups */ .gr)(await (0,utils_config_service_helpers__WEBPACK_IMPORTED_MODULE_4__/* .servicesFromConfig */ .ah)());
  } catch (e) {
    console.error("Failed to load services.yaml, please check for errors");
    if (e) console.error(e.toString());
    configuredServices = [];
  }

  try {
    initialSettings = await (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* .getSettings */ .Gw)();
  } catch (e) {
    console.error("Failed to load settings.yaml, please check for errors");
    if (e) console.error(e.toString());
    initialSettings = {};
  }

  const mergedGroupsNames = [...new Set([discoveredDockerServices.map(group => group.name), discoveredKubernetesServices.map(group => group.name), configuredServices.map(group => group.name)].flat())];
  const sortedGroups = [];
  const unsortedGroups = [];
  const definedLayouts = initialSettings.layout ? Object.keys(initialSettings.layout) : null;
  mergedGroupsNames.forEach(groupName => {
    const discoveredDockerGroup = discoveredDockerServices.find(group => group.name === groupName) || {
      services: []
    };
    const discoveredKubernetesGroup = discoveredKubernetesServices.find(group => group.name === groupName) || {
      services: []
    };
    const configuredGroup = configuredServices.find(group => group.name === groupName) || {
      services: []
    };
    const mergedGroup = {
      name: groupName,
      services: [...discoveredDockerGroup.services, ...discoveredKubernetesGroup.services, ...configuredGroup.services].filter(service => service).sort(compareServices)
    };

    if (definedLayouts) {
      const layoutIndex = definedLayouts.findIndex(layout => layout === mergedGroup.name);
      if (layoutIndex > -1) sortedGroups[layoutIndex] = mergedGroup;else unsortedGroups.push(mergedGroup);
    } else {
      unsortedGroups.push(mergedGroup);
    }
  });
  return [...sortedGroups.filter(g => g), ...unsortedGroups];
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7307:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getDockerArguments)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(626);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function getDockerArguments(server) {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP)("docker.yaml");
  const configFile = path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), "config", "docker.yaml");
  const rawConfigData = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(configFile, "utf8");
  const configData = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* .substituteEnvironmentVars */ .AI)(rawConfigData);
  const servers = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(configData);

  if (!server) {
    if (process.platform !== "win32" && process.platform !== "darwin") {
      return {
        socketPath: "/var/run/docker.sock"
      };
    }

    return {
      host: "127.0.0.1"
    };
  }

  if (servers[server]) {
    if (servers[server].socket) {
      return {
        conn: {
          socketPath: servers[server].socket
        },
        swarm: !!servers[server].swarm
      };
    }

    if (servers[server].host) {
      const res = {
        conn: {
          host: servers[server].host
        },
        swarm: !!servers[server].swarm
      };

      if (servers[server].port) {
        res.conn.port = servers[server].port;
      }

      if (servers[server].tls) {
        res.conn.ca = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), "config", servers[server].tls.caFile));
        res.conn.cert = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), "config", servers[server].tls.certFile));
        res.conn.key = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), "config", servers[server].tls.keyFile));
      }

      return res;
    }

    return servers[server];
  }

  return null;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9598:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getKubeConfig)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(626);
/* harmony import */ var _kubernetes_client_node__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(276);
/* harmony import */ var _kubernetes_client_node__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_kubernetes_client_node__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_4__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function getKubeConfig() {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP)("kubernetes.yaml");
  const configFile = path__WEBPACK_IMPORTED_MODULE_0___default().join(process.cwd(), "config", "kubernetes.yaml");
  const rawConfigData = (0,fs__WEBPACK_IMPORTED_MODULE_1__.readFileSync)(configFile, "utf8");
  const configData = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_4__/* .substituteEnvironmentVars */ .AI)(rawConfigData);
  const config = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(configData);
  const kc = new _kubernetes_client_node__WEBPACK_IMPORTED_MODULE_3__.KubeConfig();

  switch (config?.mode) {
    case 'cluster':
      kc.loadFromCluster();
      break;

    case 'default':
      kc.loadFromDefault();
      break;

    case 'disabled':
    default:
      return null;
  }

  return kc;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7771:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ah": () => (/* binding */ servicesFromConfig),
/* harmony export */   "gr": () => (/* binding */ cleanServiceGroups),
/* harmony export */   "iP": () => (/* binding */ servicesFromKubernetes),
/* harmony export */   "kr": () => (/* binding */ servicesFromDocker)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(626);
/* harmony import */ var dockerode__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4856);
/* harmony import */ var dockerode__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(dockerode__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var shvl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7044);
/* harmony import */ var shvl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(shvl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _kubernetes_client_node__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(276);
/* harmony import */ var _kubernetes_client_node__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_kubernetes_client_node__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var utils_logger__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8204);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9365);
/* harmony import */ var utils_config_docker__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7307);
/* harmony import */ var utils_config_kubernetes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9598);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_logger__WEBPACK_IMPORTED_MODULE_6__, utils_config_config__WEBPACK_IMPORTED_MODULE_7__, utils_config_docker__WEBPACK_IMPORTED_MODULE_8__, utils_config_kubernetes__WEBPACK_IMPORTED_MODULE_9__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_logger__WEBPACK_IMPORTED_MODULE_6__, utils_config_config__WEBPACK_IMPORTED_MODULE_7__, utils_config_docker__WEBPACK_IMPORTED_MODULE_8__, utils_config_kubernetes__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
const _excluded = ["name", "group"],
      _excluded2 = ["name", "group"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const logger = (0,utils_logger__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)("service-helpers");
async function servicesFromConfig() {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)("services.yaml");
  const servicesYaml = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "config", "services.yaml");
  const rawFileContents = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(servicesYaml, "utf8");
  const fileContents = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* .substituteEnvironmentVars */ .AI)(rawFileContents);
  const services = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(fileContents);

  if (!services) {
    return [];
  } // map easy to write YAML objects into easy to consume JS arrays


  const servicesArray = services.map(servicesGroup => ({
    name: Object.keys(servicesGroup)[0],
    services: servicesGroup[Object.keys(servicesGroup)[0]].map(entries => _objectSpread(_objectSpread({
      name: Object.keys(entries)[0]
    }, entries[Object.keys(entries)[0]]), {}, {
      type: 'service'
    }))
  })); // add default weight to services based on their position in the configuration

  servicesArray.forEach((group, groupIndex) => {
    group.services.forEach((service, serviceIndex) => {
      if (!service.weight) {
        servicesArray[groupIndex].services[serviceIndex].weight = (serviceIndex + 1) * 100;
      }
    });
  });
  return servicesArray;
}
async function servicesFromDocker() {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)("docker.yaml");
  const dockerYaml = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "config", "docker.yaml");
  const rawDockerFileContents = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(dockerYaml, "utf8");
  const dockerFileContents = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* .substituteEnvironmentVars */ .AI)(rawDockerFileContents);
  const servers = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(dockerFileContents);

  if (!servers) {
    return [];
  }

  const serviceServers = await Promise.all(Object.keys(servers).map(async serverName => {
    try {
      const docker = new (dockerode__WEBPACK_IMPORTED_MODULE_3___default())((0,utils_config_docker__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(serverName).conn);
      const containers = await docker.listContainers({
        all: true
      }); // bad docker connections can result in a <Buffer ...> object?
      // in any case, this ensures the result is the expected array

      if (!Array.isArray(containers)) {
        return [];
      }

      const discovered = containers.map(container => {
        let constructedService = null;
        Object.keys(container.Labels).forEach(label => {
          if (label.startsWith("homepage.")) {
            if (!constructedService) {
              constructedService = {
                container: container.Names[0].replace(/^\//, ""),
                server: serverName,
                type: 'service'
              };
            }

            shvl__WEBPACK_IMPORTED_MODULE_4__.set(constructedService, label.replace("homepage.", ""), (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* .substituteEnvironmentVars */ .AI)(container.Labels[label]));
          }
        });
        return constructedService;
      });
      return {
        server: serverName,
        services: discovered.filter(filteredService => filteredService)
      };
    } catch (e) {
      // a server failed, but others may succeed
      return {
        server: serverName,
        services: []
      };
    }
  }));
  const mappedServiceGroups = [];
  serviceServers.forEach(server => {
    server.services.forEach(serverService => {
      let serverGroup = mappedServiceGroups.find(searchedGroup => searchedGroup.name === serverService.group);

      if (!serverGroup) {
        mappedServiceGroups.push({
          name: serverService.group,
          services: []
        });
        serverGroup = mappedServiceGroups[mappedServiceGroups.length - 1];
      }

      const {
        name: serviceName,
        group: serverServiceGroup
      } = serverService,
            pushedService = _objectWithoutProperties(serverService, _excluded);

      const result = _objectSpread({
        name: serviceName
      }, pushedService);

      serverGroup.services.push(result);
    });
  });
  return mappedServiceGroups;
}

function getUrlFromIngress(ingress) {
  const urlHost = ingress.spec.rules[0].host;
  const urlPath = ingress.spec.rules[0].http.paths[0].path;
  const urlSchema = ingress.spec.tls ? 'https' : 'http';
  return `${urlSchema}://${urlHost}${urlPath}`;
}

async function servicesFromKubernetes() {
  const ANNOTATION_BASE = 'gethomepage.dev';
  const ANNOTATION_WIDGET_BASE = `${ANNOTATION_BASE}/widget.`;
  const ANNOTATION_POD_SELECTOR = `${ANNOTATION_BASE}/pod-selector`;
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)("kubernetes.yaml");

  try {
    const kc = (0,utils_config_kubernetes__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();

    if (!kc) {
      return [];
    }

    const networking = kc.makeApiClient(_kubernetes_client_node__WEBPACK_IMPORTED_MODULE_5__.NetworkingV1Api);
    const crd = kc.makeApiClient(_kubernetes_client_node__WEBPACK_IMPORTED_MODULE_5__.CustomObjectsApi);
    const ingressList = await networking.listIngressForAllNamespaces(null, null, null, null).then(response => response.body).catch(error => {
      logger.error("Error getting ingresses: %d %s %s", error.statusCode, error.body, error.response);
      return null;
    });
    const traefikIngressList = await crd.listClusterCustomObject("traefik.containo.us", "v1alpha1", "ingressroutes").then(response => response.body).catch(error => {
      logger.error("Error getting traefik ingresses: %d %s %s", error.statusCode, error.body, error.response);
      return null;
    });

    if (traefikIngressList && traefikIngressList.items.length > 0) {
      const traefikServices = traefikIngressList.items.filter(ingress => ingress.metadata.annotations && ingress.metadata.annotations[`${ANNOTATION_BASE}/href`]);
      ingressList.items.push(...traefikServices);
    }

    if (!ingressList) {
      return [];
    }

    const services = ingressList.items.filter(ingress => ingress.metadata.annotations && ingress.metadata.annotations[`${ANNOTATION_BASE}/enabled`] === 'true').map(ingress => {
      let constructedService = {
        app: ingress.metadata.name,
        namespace: ingress.metadata.namespace,
        href: ingress.metadata.annotations[`${ANNOTATION_BASE}/href`] || getUrlFromIngress(ingress),
        name: ingress.metadata.annotations[`${ANNOTATION_BASE}/name`] || ingress.metadata.name,
        group: ingress.metadata.annotations[`${ANNOTATION_BASE}/group`] || "Kubernetes",
        weight: ingress.metadata.annotations[`${ANNOTATION_BASE}/weight`] || '0',
        icon: ingress.metadata.annotations[`${ANNOTATION_BASE}/icon`] || '',
        description: ingress.metadata.annotations[`${ANNOTATION_BASE}/description`] || '',
        external: false,
        type: 'service'
      };

      if (ingress.metadata.annotations[`${ANNOTATION_BASE}/external`]) {
        constructedService.external = String(ingress.metadata.annotations[`${ANNOTATION_BASE}/external`]).toLowerCase() === "true";
      }

      if (ingress.metadata.annotations[ANNOTATION_POD_SELECTOR]) {
        constructedService.podSelector = ingress.metadata.annotations[ANNOTATION_POD_SELECTOR];
      }

      if (ingress.metadata.annotations[`${ANNOTATION_BASE}/ping`]) {
        constructedService.ping = ingress.metadata.annotations[`${ANNOTATION_BASE}/ping`];
      }

      Object.keys(ingress.metadata.annotations).forEach(annotation => {
        if (annotation.startsWith(ANNOTATION_WIDGET_BASE)) {
          shvl__WEBPACK_IMPORTED_MODULE_4__.set(constructedService, annotation.replace(`${ANNOTATION_BASE}/`, ""), ingress.metadata.annotations[annotation]);
        }
      });

      try {
        constructedService = JSON.parse((0,utils_config_config__WEBPACK_IMPORTED_MODULE_7__/* .substituteEnvironmentVars */ .AI)(JSON.stringify(constructedService)));
      } catch (e) {
        logger.error("Error attempting k8s environment variable substitution.");
      }

      return constructedService;
    });
    const mappedServiceGroups = [];
    services.forEach(serverService => {
      let serverGroup = mappedServiceGroups.find(searchedGroup => searchedGroup.name === serverService.group);

      if (!serverGroup) {
        mappedServiceGroups.push({
          name: serverService.group,
          services: []
        });
        serverGroup = mappedServiceGroups[mappedServiceGroups.length - 1];
      }

      const {
        name: serviceName,
        group: serverServiceGroup
      } = serverService,
            pushedService = _objectWithoutProperties(serverService, _excluded2);

      const result = _objectSpread({
        name: serviceName
      }, pushedService);

      serverGroup.services.push(result);
    });
    return mappedServiceGroups;
  } catch (e) {
    logger.error(e);
    throw e;
  }
}
function cleanServiceGroups(groups) {
  return groups.map(serviceGroup => ({
    name: serviceGroup.name,
    services: serviceGroup.services.map(service => {
      const cleanedService = _objectSpread({}, service);

      if (cleanedService.showStats !== undefined) cleanedService.showStats = JSON.parse(cleanedService.showStats);

      if (typeof service.weight === 'string') {
        const weight = parseInt(service.weight, 10);

        if (Number.isNaN(weight)) {
          cleanedService.weight = 0;
        } else {
          cleanedService.weight = weight;
        }
      }

      if (typeof cleanedService.weight !== "number") {
        cleanedService.weight = 0;
      }

      if (cleanedService.widget) {
        // whitelisted set of keys to pass to the frontend
        const {
          type,
          // all widgets
          fields,
          hideErrors,
          server,
          // docker widget
          container,
          currency,
          // coinmarketcap widget
          symbols,
          defaultinterval,
          site,
          // unifi widget
          namespace,
          // kubernetes widget
          app,
          podSelector,
          wan,
          // opnsense widget, pfsense widget
          enableBlocks,
          // emby/jellyfin
          enableNowPlaying,
          volume // diskstation widget

        } = cleanedService.widget;
        const fieldsList = typeof fields === 'string' ? JSON.parse(fields) : fields;
        cleanedService.widget = {
          type,
          fields: fieldsList || null,
          hide_errors: hideErrors || false,
          service_name: service.name,
          service_group: serviceGroup.name
        };
        if (currency) cleanedService.widget.currency = currency;
        if (symbols) cleanedService.widget.symbols = symbols;
        if (defaultinterval) cleanedService.widget.defaultinterval = defaultinterval;

        if (type === "docker") {
          if (server) cleanedService.widget.server = server;
          if (container) cleanedService.widget.container = container;
        }

        if (type === "unifi") {
          if (site) cleanedService.widget.site = site;
        }

        if (type === "kubernetes") {
          if (namespace) cleanedService.widget.namespace = namespace;
          if (app) cleanedService.widget.app = app;
          if (podSelector) cleanedService.widget.podSelector = podSelector;
        }

        if (["opnsense", "pfsense"].includes(type)) {
          if (wan) cleanedService.widget.wan = wan;
        }

        if (["emby", "jellyfin"].includes(type)) {
          if (enableBlocks !== undefined) cleanedService.widget.enableBlocks = JSON.parse(enableBlocks);
          if (enableNowPlaying !== undefined) cleanedService.widget.enableNowPlaying = JSON.parse(enableNowPlaying);
        }

        if (["diskstation", "qnap"].includes(type)) {
          if (volume) cleanedService.widget.volume = volume;
        }
      }

      return cleanedService;
    })
  }));
}
async function getServiceWidget(group, service) {
  const configuredServices = await servicesFromConfig();
  const serviceGroup = configuredServices.find(g => g.name === group);

  if (serviceGroup) {
    const serviceEntry = serviceGroup.services.find(s => s.name === service);

    if (serviceEntry) {
      const {
        widget
      } = serviceEntry;
      return widget;
    }
  }

  const discoveredServices = await servicesFromDocker();
  const dockerServiceGroup = discoveredServices.find(g => g.name === group);

  if (dockerServiceGroup) {
    const dockerServiceEntry = dockerServiceGroup.services.find(s => s.name === service);

    if (dockerServiceEntry) {
      const {
        widget
      } = dockerServiceEntry;
      return widget;
    }
  }

  const kubernetesServices = await servicesFromKubernetes();
  const kubernetesServiceGroup = kubernetesServices.find(g => g.name === group);

  if (kubernetesServiceGroup) {
    const kubernetesServiceEntry = kubernetesServiceGroup.services.find(s => s.name === service);

    if (kubernetesServiceEntry) {
      const {
        widget
      } = kubernetesServiceEntry;
      return widget;
    }
  }

  return false;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1581:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "qz": () => (/* binding */ cleanWidgetGroups),
/* harmony export */   "uN": () => (/* binding */ widgetsFromConfig)
/* harmony export */ });
/* unused harmony export getPrivateWidgetOptions */
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(626);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__]);
([js_yaml__WEBPACK_IMPORTED_MODULE_2__, utils_config_config__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





async function widgetsFromConfig() {
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP)("widgets.yaml");
  const widgetsYaml = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "config", "widgets.yaml");
  const rawFileContents = await fs__WEBPACK_IMPORTED_MODULE_0__.promises.readFile(widgetsYaml, "utf8");
  const fileContents = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* .substituteEnvironmentVars */ .AI)(rawFileContents);
  const widgets = js_yaml__WEBPACK_IMPORTED_MODULE_2__["default"].load(fileContents);
  if (!widgets) return []; // map easy to write YAML objects into easy to consume JS arrays

  const widgetsArray = widgets.map((group, index) => ({
    type: Object.keys(group)[0],
    options: _objectSpread({
      index
    }, group[Object.keys(group)[0]])
  }));
  return widgetsArray;
}
async function cleanWidgetGroups(widgets) {
  return widgets.map((widget, index) => {
    const sanitizedOptions = widget.options;
    const optionKeys = Object.keys(sanitizedOptions); // delete private options from the sanitized options

    ["username", "password", "key"].forEach(pO => {
      if (optionKeys.includes(pO)) {
        delete sanitizedOptions[pO];
      }
    }); // delete url from the sanitized options if the widget is not a search or glances widgeth

    if (widget.type !== "search" && widget.type !== "glances" && optionKeys.includes("url")) {
      delete sanitizedOptions.url;
    }

    return {
      type: widget.type,
      options: _objectSpread({
        index
      }, sanitizedOptions)
    };
  });
}
async function getPrivateWidgetOptions(type, widgetIndex) {
  const widgets = await widgetsFromConfig();
  const privateOptions = widgets.map(widget => {
    const {
      index,
      url,
      username,
      password,
      key
    } = widget.options;
    return {
      type: widget.type,
      options: {
        index,
        url,
        username,
        password,
        key
      }
    };
  });
  return type !== undefined && widgetIndex !== undefined ? privateOptions.find(o => o.type === type && o.options.index === parseInt(widgetIndex, 10))?.options : privateOptions;
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


const hasFocus = () => typeof document !== "undefined" && document.hasFocus();

const useWindowFocus = () => {
  const {
    0: focused,
    1: setFocused
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(hasFocus);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    setFocused(hasFocus());

    const onFocus = () => setFocused(true);

    const onBlur = () => setFocused(false);

    window.addEventListener("focus", onFocus);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("focus", onFocus);
      window.removeEventListener("blur", onBlur);
    };
  }, []);
  return focused;
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWindowFocus);

/***/ }),

/***/ 8204:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ createLogger)
/* harmony export */ });
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var node_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7261);
/* harmony import */ var node_util__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(node_util__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var winston__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7773);
/* harmony import */ var winston__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(winston__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var utils_config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9365);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_config_config__WEBPACK_IMPORTED_MODULE_3__]);
utils_config_config__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable no-console */




let winstonLogger;

function init() {
  const configPath = (0,path__WEBPACK_IMPORTED_MODULE_0__.join)(process.cwd(), "config");
  (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP)("settings.yaml");
  const settings = (0,utils_config_config__WEBPACK_IMPORTED_MODULE_3__/* .getSettings */ .Gw)();
  const logpath = settings.logpath || configPath;

  function combineMessageAndSplat() {
    return {
      // eslint-disable-next-line no-unused-vars
      transform: (info, opts) => {
        // combine message and args if any
        // eslint-disable-next-line no-param-reassign
        info.message = (0,node_util__WEBPACK_IMPORTED_MODULE_1__.format)(info.message, ...(info[Symbol.for("splat")] || []));
        return info;
      }
    };
  }

  function messageFormatter(logInfo) {
    if (logInfo.label) {
      if (logInfo.stack) {
        return `[${logInfo.timestamp}] ${logInfo.level}: <${logInfo.label}> ${logInfo.stack}`;
      }

      return `[${logInfo.timestamp}] ${logInfo.level}: <${logInfo.label}> ${logInfo.message}`;
    }

    if (logInfo.stack) {
      return `[${logInfo.timestamp}] ${logInfo.level}: ${logInfo.stack}`;
    }

    return `[${logInfo.timestamp}] ${logInfo.level}: ${logInfo.message}`;
  }

  winstonLogger = winston__WEBPACK_IMPORTED_MODULE_2___default().createLogger({
    level: process.env.LOG_LEVEL || "info",
    transports: [new (winston__WEBPACK_IMPORTED_MODULE_2___default().transports.Console)({
      format: winston__WEBPACK_IMPORTED_MODULE_2___default().format.combine(winston__WEBPACK_IMPORTED_MODULE_2___default().format.errors({
        stack: true
      }), combineMessageAndSplat(), winston__WEBPACK_IMPORTED_MODULE_2___default().format.timestamp(), winston__WEBPACK_IMPORTED_MODULE_2___default().format.colorize(), winston__WEBPACK_IMPORTED_MODULE_2___default().format.printf(messageFormatter)),
      handleExceptions: true,
      handleRejections: true
    }), new (winston__WEBPACK_IMPORTED_MODULE_2___default().transports.File)({
      format: winston__WEBPACK_IMPORTED_MODULE_2___default().format.combine(winston__WEBPACK_IMPORTED_MODULE_2___default().format.errors({
        stack: true
      }), combineMessageAndSplat(), winston__WEBPACK_IMPORTED_MODULE_2___default().format.timestamp(), winston__WEBPACK_IMPORTED_MODULE_2___default().format.printf(messageFormatter)),
      filename: `${logpath}/logs/homepage.log`,
      handleExceptions: true,
      handleRejections: true
    })]
  }); // patch the console log mechanism to use our logger

  const consoleMethods = ["log", "debug", "info", "warn", "error"];
  consoleMethods.forEach(method => {
    // workaround for https://github.com/winstonjs/winston/issues/1591
    switch (method) {
      case "log":
        console[method] = winstonLogger.info.bind(winstonLogger);
        break;

      default:
        console[method] = winstonLogger[method].bind(winstonLogger);
        break;
    }
  });
}

const loggers = {};
function createLogger(label) {
  if (!winstonLogger) {
    init();
  }

  if (!loggers[label]) {
    loggers[label] = winstonLogger.child({
      label
    });
  }

  return loggers[label];
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2613:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Component)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _stats_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6817);
/* harmony import */ var components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7816);
/* harmony import */ var components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(403);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function Component({
  service
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const {
    widget
  } = service;
  const {
    data: statusData,
    error: statusError
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/docker/status/${widget.container}/${widget.server || ""}`);
  const {
    data: statsData,
    error: statsError
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/docker/stats/${widget.container}/${widget.server || ""}`);

  if (statsError || statsData?.error || statusError || statusData?.error) {
    const finalError = statsError ?? statsData?.error ?? statusError ?? statusData?.error;
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      service: service,
      error: finalError
    });
  }

  if (statusData && !(statusData.status.includes("running") || statusData.status.includes("partial"))) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: t("widget.status"),
        value: t("docker.offline")
      })
    });
  }

  if (!statsData || !statusData) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      service: service,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.cpu"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.mem"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.rx"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.tx"
      })]
    });
  }

  const network = statsData.stats.networks?.eth0 || statsData.stats.networks?.network;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    service: service,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      label: "docker.cpu",
      value: t("common.percent", {
        value: (0,_stats_helpers__WEBPACK_IMPORTED_MODULE_5__/* .calculateCPUPercent */ .A)(statsData.stats)
      })
    }), statsData.stats.memory_stats.usage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      label: "docker.mem",
      value: t("common.bytes", {
        value: (0,_stats_helpers__WEBPACK_IMPORTED_MODULE_5__/* .calculateUsedMemory */ .v)(statsData.stats)
      })
    }), network && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.rx",
        value: t("common.bytes", {
          value: network.rx_bytes
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.tx",
        value: t("common.bytes", {
          value: network.tx_bytes
        })
      })]
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6817:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ calculateCPUPercent),
/* harmony export */   "v": () => (/* binding */ calculateUsedMemory)
/* harmony export */ });
function calculateCPUPercent(stats) {
  let cpuPercent = 0.0;
  const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
  const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;

  if (systemDelta > 0.0 && cpuDelta > 0.0) {
    cpuPercent = cpuDelta / systemDelta * stats.cpu_stats.online_cpus * 100.0;
  }

  return Math.round(cpuPercent * 10) / 10;
}
function calculateUsedMemory(stats) {
  return stats.memory_stats.usage - (stats.memory_stats.stats.cache ?? 0);
}

/***/ }),

/***/ 5889:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Component)
/* harmony export */ });
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5941);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7816);
/* harmony import */ var components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(403);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_0__]);
swr__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Component({
  service
}) {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const {
    widget
  } = service;
  const podSelectorString = widget.podSelector !== undefined ? `podSelector=${widget.podSelector}` : "";
  const {
    data: statusData,
    error: statusError
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/kubernetes/status/${widget.namespace}/${widget.app}?${podSelectorString}`);
  const {
    data: statsData,
    error: statsError
  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__["default"])(`/api/kubernetes/stats/${widget.namespace}/${widget.app}?${podSelectorString}`);

  if (statsError || statusError) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      service: service,
      error: t("widget.api_error")
    });
  }

  if (statusData && statusData.status !== "running") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: t("widget.status"),
        value: t("docker.offline")
      })
    });
  }

  if (!statsData || !statusData) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
      service: service,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.cpu"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        label: "docker.mem"
      })]
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(components_services_widget_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
    service: service,
    children: [statsData.stats.cpuLimit && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      label: "docker.cpu",
      value: t("common.percent", {
        value: statsData.stats.cpuUsage
      })
    }) || /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      label: "docker.cpu",
      value: t("common.number", {
        value: statsData.stats.cpu,
        maximumFractionDigits: 4
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(components_services_widget_block__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      label: "docker.mem",
      value: t("common.bytes", {
        value: statsData.stats.mem
      })
    })]
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 276:
/***/ ((module) => {

module.exports = require("@kubernetes/client-node");

/***/ }),

/***/ 7281:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 7795:
/***/ ((module) => {

module.exports = require("compare-versions");

/***/ }),

/***/ 4856:
/***/ ((module) => {

module.exports = require("dockerode");

/***/ }),

/***/ 2108:
/***/ ((module) => {

module.exports = require("memory-cache");

/***/ }),

/***/ 1377:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 5460:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9709:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 9989:
/***/ ((module) => {

module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 764:
/***/ ((module) => {

module.exports = require("react-icons/si");

/***/ }),

/***/ 5744:
/***/ ((module) => {

module.exports = require("react-icons/wi");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7044:
/***/ ((module) => {

module.exports = require("shvl");

/***/ }),

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 626:
/***/ ((module) => {

module.exports = import("js-yaml");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 7261:
/***/ ((module) => {

module.exports = require("node:util");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [4573,7068,4258], () => (__webpack_exec__(6243)));
module.exports = __webpack_exports__;

})();